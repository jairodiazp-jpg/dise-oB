// Datos simulados para el sistema
export interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'empresa' | 'profesional'
  empresaId?: string
  empresaNombre?: string
  especialidad?: string
  telefono?: string
  avatar?: string
}

export interface Empresa {
  id: string
  nombre: string
  direccion: string
  telefono: string
  email: string
  logo?: string
  activa: boolean
}

export interface Profesional {
  id: string
  nombre: string
  email: string
  especialidad: string
  telefono: string
  empresaId: string
  empresaNombre: string
  activo: boolean
  avatar?: string
}

export interface Cita {
  id: string
  pacienteNombre: string
  pacienteTelefono: string
  pacienteEmail: string
  profesionalId: string
  profesionalNombre: string
  empresaId: string
  empresaNombre: string
  fecha: string
  hora: string
  duracion: number
  tipo: string
  estado: 'confirmada' | 'pendiente' | 'cancelada' | 'completada'
  notas?: string
  createdAt: string
}

export interface HoraTrabajada {
  id: string
  profesionalId: string
  profesionalNombre: string
  empresaId: string
  empresaNombre: string
  fecha: string
  horaInicio: string
  horaFin: string
  totalHoras: number
  descripcion?: string
  createdAt: string
}

export interface Notificacion {
  id: string
  titulo: string
  mensaje: string
  tipo: 'info' | 'warning' | 'success' | 'error'
  destinatarioId: string
  destinatarioTipo: 'admin' | 'empresa' | 'profesional'
  leida: boolean
  createdAt: string
}

// Mock data actualizado
export const mockEmpresas: Empresa[] = [
  {
    id: '1',
    nombre: 'Clínica Vida',
    direccion: 'Calle 123 #45-67, Bogotá',
    telefono: '+57 1 234-5678',
    email: 'contacto@clinicavida.com',
    activa: true
  },
  {
    id: '2',
    nombre: 'Centro Médico Salud',
    direccion: 'Carrera 45 #12-34, Medellín',
    telefono: '+57 4 567-8901',
    email: 'info@centromedicosalud.com',
    activa: true
  },
  {
    id: '3',
    nombre: 'Hospital San José',
    direccion: 'Avenida 67 #89-12, Cali',
    telefono: '+57 2 890-1234',
    email: 'contacto@hospitalsanjose.com',
    activa: true
  }
]

export const mockProfesionales: Profesional[] = [
  {
    id: '7',
    nombre: 'Dra. Ana María González',
    email: 'ana.gonzalez@clinicavida.com',
    especialidad: 'Cardiología',
    telefono: '+57 300 123-4567',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    activo: true
  },
  {
    id: '8',
    nombre: 'Dr. Carlos Rodríguez',
    email: 'carlos.rodriguez@clinicavida.com',
    especialidad: 'Neurología',
    telefono: '+57 300 234-5678',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    activo: true
  },
  {
    id: '9',
    nombre: 'Dra. Laura Martínez',
    email: 'laura.martinez@clinicavida.com',
    especialidad: 'Pediatría',
    telefono: '+57 300 345-6789',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    activo: true
  },
  {
    id: '10',
    nombre: 'Dr. Miguel Torres',
    email: 'miguel.torres@centromedicosalud.com',
    especialidad: 'Ortopedia',
    telefono: '+57 300 456-7890',
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
    activo: true
  },
  {
    id: '11',
    nombre: 'Dra. Sofía Herrera',
    email: 'sofia.herrera@centromedicosalud.com',
    especialidad: 'Ginecología',
    telefono: '+57 300 567-8901',
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
    activo: true
  },
  {
    id: '12',
    nombre: 'Dr. Ricardo López',
    email: 'ricardo.lopez@hospitalsanjose.com',
    especialidad: 'Cirugía General',
    telefono: '+57 300 678-9012',
    empresaId: '3',
    empresaNombre: 'Hospital San José',
    activo: true
  }
]

export const mockCitas: Cita[] = [
  {
    id: '1',
    pacienteNombre: 'María González',
    pacienteTelefono: '+57 300 111-2222',
    pacienteEmail: 'maria.gonzalez@email.com',
    profesionalId: '7',
    profesionalNombre: 'Dra. Ana María González',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    fecha: '2024-01-15',
    hora: '09:00',
    duracion: 30,
    tipo: 'Consulta General',
    estado: 'confirmada',
    notas: 'Control de presión arterial',
    createdAt: '2024-01-10T10:00:00Z'
  },
  {
    id: '2',
    pacienteNombre: 'Carlos Ruiz',
    pacienteTelefono: '+57 300 222-3333',
    pacienteEmail: 'carlos.ruiz@email.com',
    profesionalId: '7',
    profesionalNombre: 'Dra. Ana María González',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    fecha: '2024-01-15',
    hora: '10:30',
    duracion: 45,
    tipo: 'Seguimiento',
    estado: 'pendiente',
    notas: 'Revisión de exámenes',
    createdAt: '2024-01-10T11:00:00Z'
  }
]

export const mockHorasTrabajadas: HoraTrabajada[] = [
  {
    id: '1',
    profesionalId: '7',
    profesionalNombre: 'Dra. Ana María González',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    fecha: '2024-01-15',
    horaInicio: '08:00',
    horaFin: '16:00',
    totalHoras: 8,
    descripcion: 'Consultas generales y procedimientos',
    createdAt: '2024-01-15T16:00:00Z'
  },
  {
    id: '2',
    profesionalId: '8',
    profesionalNombre: 'Dr. Carlos Rodríguez',
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    fecha: '2024-01-15',
    horaInicio: '09:00',
    horaFin: '17:00',
    totalHoras: 8,
    descripcion: 'Consultas neurológicas',
    createdAt: '2024-01-15T17:00:00Z'
  }
]

export const mockNotificaciones: Notificacion[] = [
  {
    id: '1',
    titulo: 'Nueva cita agendada',
    mensaje: 'Se ha agendado una nueva cita para mañana a las 10:00 AM',
    tipo: 'info',
    destinatarioId: '7',
    destinatarioTipo: 'profesional',
    leida: false,
    createdAt: '2024-01-15T10:00:00Z'
  },
  {
    id: '2',
    titulo: 'Recordatorio de cita',
    mensaje: 'Tienes una cita en 30 minutos con María González',
    tipo: 'warning',
    destinatarioId: '7',
    destinatarioTipo: 'profesional',
    leida: false,
    createdAt: '2024-01-15T08:30:00Z'
  }
]
