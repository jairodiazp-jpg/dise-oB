'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, ChevronRight, Calendar, Plus, Ban, Clock, Stethoscope, Sparkles } from 'lucide-react'
import { formatDate, getDayName, getWeekDates, getMonthDates, isToday } from '@/lib/utils/date-utils'
import { mockCitas, mockHorasTrabajadas, type Cita, type HoraTrabajada } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'
import { cn } from '@/lib/utils'

interface BloqueoHorario {
  id: string
  profesionalId: string
  fecha: string
  horaInicio: string
  horaFin: string
  tipoBloqueo: string
  motivo: string
  descripcion?: string
}

interface AgendaIntegradaProps {
  profesionalId?: string
  empresaId?: string
  onNewCita?: () => void
  onBloquearHorario?: (fecha?: string, hora?: string) => void
}

export function AgendaIntegrada({ profesionalId, empresaId, onNewCita, onBloquearHorario }: AgendaIntegradaProps) {
  const { user } = useAuth()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<'day' | 'week' | 'month'>('week')
  const [bloqueos, setBloqueos] = useState<BloqueoHorario[]>([])
  const [refreshKey, setRefreshKey] = useState(0)

  // Simular datos en tiempo real
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1)
    }, 30000) // Actualizar cada 30 segundos

    return () => clearInterval(interval)
  }, [])

  const filteredCitas = mockCitas.filter(cita => {
    if (profesionalId) return cita.profesionalId === profesionalId
    if (empresaId) return cita.empresaId === empresaId
    return true
  })

  const filteredHoras = mockHorasTrabajadas.filter(hora => {
    if (profesionalId) return hora.profesionalId === profesionalId
    if (empresaId) return hora.empresaId === empresaId
    return true
  })

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate)
    switch (view) {
      case 'day':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1))
        break
      case 'week':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7))
        break
      case 'month':
        newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1))
        break
    }
    setCurrentDate(newDate)
  }

  const getCitasForDate = (date: Date): Cita[] => {
    const dateStr = date.toISOString().split('T')[0]
    return filteredCitas.filter(cita => cita.fecha === dateStr)
  }

  const getHorasForDate = (date: Date): HoraTrabajada[] => {
    const dateStr = date.toISOString().split('T')[0]
    return filteredHoras.filter(hora => hora.fecha === dateStr)
  }

  const getBloqueosForDate = (date: Date): BloqueoHorario[] => {
    const dateStr = date.toISOString().split('T')[0]
    return bloqueos.filter(bloqueo => bloqueo.fecha === dateStr)
  }

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'confirmada':
        return 'bg-green-100 text-green-800 border-green-300'
      case 'pendiente':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300'
      case 'cancelada':
        return 'bg-red-100 text-red-800 border-red-300'
      case 'completada':
        return 'bg-green-200 text-green-900 border-green-400'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300'
    }
  }

  const getTipoBloqueoColor = (tipo: string) => {
    switch (tipo) {
      case 'personal':
        return 'bg-red-100 text-red-800 border-red-300'
      case 'almuerzo':
        return 'bg-orange-100 text-orange-800 border-orange-300'
      case 'reunion':
        return 'bg-purple-100 text-purple-800 border-purple-300'
      case 'capacitacion':
        return 'bg-green-100 text-green-800 border-green-300'
      case 'emergencia':
        return 'bg-red-200 text-red-900 border-red-400'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300'
    }
  }

  const renderDayView = () => {
    const citasDelDia = getCitasForDate(currentDate)
    const horasDelDia = getHorasForDate(currentDate)
    const bloqueosDelDia = getBloqueosForDate(currentDate)
    const horas = Array.from({ length: 12 }, (_, i) => i + 8) // 8 AM to 7 PM

    return (
      <div className="space-y-2">
        {horas.map(hora => {
          const horaStr = `${hora.toString().padStart(2, '0')}:00`
          const citaEnHora = citasDelDia.find(cita => cita.hora.startsWith(hora.toString().padStart(2, '0')))
          const bloqueoEnHora = bloqueosDelDia.find(bloqueo => 
            hora >= parseInt(bloqueo.horaInicio.split(':')[0]) && 
            hora < parseInt(bloqueo.horaFin.split(':')[0])
          )

          return (
            <div key={hora} className="flex items-start space-x-4 min-h-[80px] border-b border-gray-100 pb-4">
              <div className="w-16 text-sm text-gray-500 font-semibold pt-2 bg-gray-50 rounded-lg px-2 py-1 text-center">
                {horaStr}
              </div>
              <div className="flex-1">
                {bloqueoEnHora ? (
                  <div className={`border-2 rounded-xl p-4 shadow-sm ${getTipoBloqueoColor(bloqueoEnHora.tipoBloqueo)}`}>
                    <div className="flex items-center space-x-2 mb-2">
                      <Ban className="h-5 w-5" />
                      <h4 className="font-bold">🚫 BLOQUEADO - {bloqueoEnHora.motivo}</h4>
                    </div>
                    <p className="text-sm font-medium">
                      {bloqueoEnHora.horaInicio} - {bloqueoEnHora.horaFin}
                    </p>
                    {bloqueoEnHora.descripcion && (
                      <p className="text-sm mt-1">{bloqueoEnHora.descripcion}</p>
                    )}
                  </div>
                ) : citaEnHora ? (
                  <div className="bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center space-x-3">
                        <Stethoscope className="h-5 w-5 text-green-600" />
                        <div>
                          <h4 className="font-bold text-gray-900">{citaEnHora.pacienteNombre}</h4>
                          <p className="text-sm text-gray-700 font-medium">{citaEnHora.tipo}</p>
                          <p className="text-xs text-gray-600">{citaEnHora.profesionalNombre}</p>
                        </div>
                      </div>
                      <Badge className={`${getEstadoColor(citaEnHora.estado)} font-semibold`}>
                        {citaEnHora.estado}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-700 font-medium">
                      ⏰ {citaEnHora.hora} - {citaEnHora.duracion} minutos
                    </div>
                    {citaEnHora.notas && (
                      <p className="text-sm text-gray-600 mt-2 bg-white/50 p-2 rounded-lg">{citaEnHora.notas}</p>
                    )}
                  </div>
                ) : (
                  <div className="flex space-x-2">
                    <button 
                      className="text-gray-400 text-sm pt-2 cursor-pointer hover:text-green-600 flex-1 text-left bg-gray-50 hover:bg-green-50 p-3 rounded-xl transition-all duration-200 border-2 border-dashed border-gray-200 hover:border-green-300"
                      onClick={onNewCita}
                    >
                      ✨ Disponible para agendar cita
                    </button>
                    {user?.role === 'profesional' && (
                      <button 
                        className="text-gray-400 text-sm pt-2 cursor-pointer hover:text-red-600 bg-gray-50 hover:bg-red-50 p-3 rounded-xl transition-all duration-200 border-2 border-dashed border-gray-200 hover:border-red-300"
                        onClick={() => onBloquearHorario?.(currentDate.toISOString().split('T')[0], horaStr)}
                      >
                        🚫 Bloquear
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )
        })}

        {/* Mostrar horas trabajadas del día */}
        {horasDelDia.length > 0 && (
          <div className="mt-6 p-5 bg-gradient-to-r from-green-50 to-yellow-50 border-2 border-green-200 rounded-xl shadow-sm">
            <h4 className="font-bold text-green-800 mb-3 flex items-center text-lg">
              <Clock className="h-5 w-5 mr-2" />
              ⏱️ Horas Trabajadas Registradas
            </h4>
            {horasDelDia.map(hora => (
              <div key={hora.id} className="text-sm text-green-700 bg-white/70 p-3 rounded-lg mb-2">
                <p className="font-semibold">🕐 {hora.horaInicio} - {hora.horaFin} ({hora.totalHoras} horas)</p>
                {hora.descripcion && <p className="text-green-600 mt-1">📝 {hora.descripcion}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }

  const renderWeekView = () => {
    const weekDates = getWeekDates(currentDate)

    return (
      <div className="grid grid-cols-7 gap-4">
        {weekDates.map(date => {
          const citasDelDia = getCitasForDate(date)
          const horasDelDia = getHorasForDate(date)
          const bloqueosDelDia = getBloqueosForDate(date)
          
          return (
            <div key={date.toISOString()} className="space-y-2">
              <div className={cn(
                "text-center p-3 rounded-xl shadow-sm border-2",
                isToday(date) 
                  ? "bg-gradient-to-b from-green-600 to-green-700 text-white border-green-500 shadow-lg" 
                  : "bg-gradient-to-b from-gray-50 to-gray-100 border-gray-200"
              )}>
                <div className="text-xs font-semibold uppercase tracking-wide">
                  {getDayName(date).substring(0, 3)}
                </div>
                <div className="text-xl font-bold">
                  {date.getDate()}
                </div>
              </div>
              
              <div className="space-y-2 min-h-[300px]">
                {/* Citas */}
                {citasDelDia.map(cita => (
                  <div key={cita.id} className="bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 rounded-lg p-3 text-xs shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center space-x-1 mb-1">
                      <Stethoscope className="h-3 w-3 text-green-600" />
                      <div className="font-bold text-green-800">{cita.hora}</div>
                    </div>
                    <div className="truncate font-semibold text-gray-900">{cita.pacienteNombre}</div>
                    <div className="text-gray-700 truncate font-medium">{cita.tipo}</div>
                  </div>
                ))}

                {/* Bloqueos */}
                {bloqueosDelDia.map(bloqueo => (
                  <div key={bloqueo.id} className={`border-2 rounded-lg p-3 text-xs shadow-sm ${getTipoBloqueoColor(bloqueo.tipoBloqueo)}`}>
                    <div className="flex items-center space-x-1 mb-1">
                      <Ban className="h-3 w-3" />
                      <div className="font-bold">{bloqueo.horaInicio}-{bloqueo.horaFin}</div>
                    </div>
                    <div className="truncate font-semibold">🚫 BLOQUEADO</div>
                    <div className="truncate font-medium">{bloqueo.motivo}</div>
                  </div>
                ))}

                {/* Horas trabajadas */}
                {horasDelDia.map(hora => (
                  <div key={hora.id} className="bg-gradient-to-r from-green-50 to-yellow-50 border-2 border-green-200 rounded-lg p-3 text-xs shadow-sm">
                    <div className="flex items-center space-x-1 mb-1">
                      <Clock className="h-3 w-3 text-green-600" />
                      <div className="font-bold text-green-800">{hora.horaInicio}-{hora.horaFin}</div>
                    </div>
                    <div className="truncate font-semibold text-green-900">⏱️ {hora.totalHoras}h trabajadas</div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <Card className="seguros-card">
      <CardHeader className="bg-gradient-to-r from-green-50 to-yellow-50 border-b border-green-100">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center text-xl">
            <Calendar className="h-6 w-6 mr-3 text-green-600" />
            📅 Agenda Integrada
            <Badge variant="outline" className="ml-3 text-xs bg-green-100 text-green-800 border-green-300">
              <Sparkles className="h-3 w-3 mr-1" />
              Tiempo Real
            </Badge>
          </CardTitle>
          <div className="flex space-x-2">
            {onNewCita && (
              <Button onClick={onNewCita} className="seguros-button-primary">
                <Plus className="h-4 w-4 mr-2" />
                Nueva Cita
              </Button>
            )}
            {user?.role === 'profesional' && onBloquearHorario && (
              <Button onClick={() => onBloquearHorario()} variant="outline" className="border-red-300 text-red-700 hover:bg-red-50 font-semibold">
                <Ban className="h-4 w-4 mr-2" />
                Bloquear Horario
              </Button>
            )}
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            {(['day', 'week', 'month'] as const).map(viewType => (
              <Button
                key={viewType}
                variant={view === viewType ? 'default' : 'outline'}
                size="sm"
                onClick={() => setView(viewType)}
                className={view === viewType ? 'seguros-button-primary' : 'hover:bg-green-50 border-green-200'}
              >
                {viewType === 'day' ? '📅 Día' : viewType === 'week' ? '📊 Semana' : '🗓️ Mes'}
              </Button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate('prev')} className="hover:bg-green-50 border-green-200">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="px-4 py-2 bg-white rounded-lg border-2 border-green-200 min-w-[200px] text-center shadow-sm">
              <span className="font-semibold text-green-800">
                {view === 'day' && formatDate(currentDate)}
                {view === 'week' && `Semana del ${formatDate(getWeekDates(currentDate)[0])}`}
                {view === 'month' && currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigateDate('next')} className="hover:bg-green-50 border-green-200">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        {view === 'day' && renderDayView()}
        {view === 'week' && renderWeekView()}
        {view === 'month' && (
          <div className="text-center py-12 text-gray-500">
            <Calendar className="h-20 w-20 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">Vista mensual próximamente</p>
            <p className="text-sm">Estamos trabajando en esta funcionalidad</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
