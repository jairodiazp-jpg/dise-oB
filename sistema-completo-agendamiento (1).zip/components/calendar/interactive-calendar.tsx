'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, ChevronRight, Calendar, Plus, Edit, Trash2, Clock, User, Sparkles } from 'lucide-react'
import { formatDate, getDayName, getWeekDates, isToday } from '@/lib/utils/date-utils'
import { mockCitas, type Cita } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'
import { cn } from '@/lib/utils'
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd'

interface InteractiveCalendarProps {
  profesionalId?: string
  empresaId?: string
  onNewCita?: (fecha?: string, hora?: string) => void
  onEditCita?: (cita: Cita) => void
  onDeleteCita?: (citaId: string) => void
  realTimeUpdates?: boolean
}

export function InteractiveCalendar({ 
  profesionalId, 
  empresaId, 
  onNewCita, 
  onEditCita, 
  onDeleteCita,
  realTimeUpdates = true 
}: InteractiveCalendarProps) {
  const { user } = useAuth()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<'day' | 'week' | 'month'>('week')
  const [citas, setCitas] = useState<Cita[]>(mockCitas)
  const [draggedCita, setDraggedCita] = useState<Cita | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  // Simulación de tiempo real
  useEffect(() => {
    if (!realTimeUpdates) return
    
    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1)
      // Simular actualizaciones en tiempo real
      setCitas(prev => [...prev])
    }, 5000) // Actualizar cada 5 segundos

    return () => clearInterval(interval)
  }, [realTimeUpdates])

  const filteredCitas = citas.filter(cita => {
    if (profesionalId) return cita.profesionalId === profesionalId
    if (empresaId) return cita.empresaId === empresaId
    return true
  })

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate)
    switch (view) {
      case 'day':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1))
        break
      case 'week':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7))
        break
      case 'month':
        newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1))
        break
    }
    setCurrentDate(newDate)
  }

  const getCitasForDate = (date: Date): Cita[] => {
    const dateStr = date.toISOString().split('T')[0]
    return filteredCitas.filter(cita => cita.fecha === dateStr)
  }

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'confirmada':
        return 'bg-green-100 text-green-800 border-green-300'
      case 'pendiente':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300'
      case 'cancelada':
        return 'bg-red-100 text-red-800 border-red-300'
      case 'completada':
        return 'bg-green-200 text-green-900 border-green-400'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300'
    }
  }

  const handleDragEnd = useCallback((result: any) => {
    if (!result.destination) return

    const { source, destination } = result
    const citaId = result.draggableId

    // Simular movimiento de cita
    const cita = citas.find(c => c.id === citaId)
    if (cita) {
      const updatedCita = {
        ...cita,
        fecha: destination.droppableId,
        hora: `${Math.floor(Math.random() * 12) + 8}:00` // Hora aleatoria para demo
      }
      
      setCitas(prev => prev.map(c => c.id === citaId ? updatedCita : c))
    }
  }, [citas])

  const handleDoubleClick = (fecha: string, hora?: string) => {
    onNewCita?.(fecha, hora)
  }

  const renderDayView = () => {
    const citasDelDia = getCitasForDate(currentDate)
    const horas = Array.from({ length: 12 }, (_, i) => i + 8) // 8 AM to 7 PM
    const fechaStr = currentDate.toISOString().split('T')[0]

    return (
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="space-y-2">
          {horas.map(hora => {
            const horaStr = `${hora.toString().padStart(2, '0')}:00`
            const citasEnHora = citasDelDia.filter(cita => 
              cita.hora.startsWith(hora.toString().padStart(2, '0'))
            )

            return (
              <div key={hora} className="flex items-start space-x-4 min-h-[100px] border-b border-gray-100 pb-4">
                <div className="w-20 text-sm text-gray-500 font-semibold pt-2 bg-gradient-to-r from-green-50 to-yellow-50 rounded-lg px-3 py-2 text-center border border-green-200">
                  {horaStr}
                </div>
                
                <Droppable droppableId={`${fechaStr}-${hora}`} direction="vertical">
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={cn(
                        "flex-1 min-h-[80px] rounded-xl border-2 border-dashed transition-all duration-200",
                        snapshot.isDraggingOver 
                          ? "border-green-400 bg-green-50" 
                          : "border-gray-200 hover:border-green-300 hover:bg-green-50/30"
                      )}
                      onDoubleClick={() => handleDoubleClick(fechaStr, horaStr)}
                    >
                      {citasEnHora.length === 0 ? (
                        <div className="flex items-center justify-center h-full text-gray-400 cursor-pointer">
                          <div className="text-center">
                            <Plus className="h-6 w-6 mx-auto mb-2" />
                            <p className="text-sm">Doble clic para agendar</p>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2 p-2">
                          {citasEnHora.map((cita, index) => (
                            <Draggable key={cita.id} draggableId={cita.id} index={index}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={cn(
                                    "bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-200 cursor-move group",
                                    snapshot.isDragging && "shadow-lg rotate-2 scale-105"
                                  )}
                                  onDoubleClick={() => onEditCita?.(cita)}
                                >
                                  <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center space-x-2">
                                      <User className="h-4 w-4 text-green-600" />
                                      <div>
                                        <h4 className="font-bold text-gray-900">{cita.pacienteNombre}</h4>
                                        <p className="text-sm text-gray-700">{cita.tipo}</p>
                                      </div>
                                    </div>
                                    <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          onEditCita?.(cita)
                                        }}
                                        className="h-6 w-6 p-0 hover:bg-green-200"
                                      >
                                        <Edit className="h-3 w-3" />
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          onDeleteCita?.(cita.id)
                                        }}
                                        className="h-6 w-6 p-0 hover:bg-red-200 text-red-600"
                                      >
                                        <Trash2 className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                  
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                                      <Clock className="h-3 w-3" />
                                      <span>{cita.hora} - {cita.duracion} min</span>
                                    </div>
                                    <Badge className={getEstadoColor(cita.estado)}>
                                      {cita.estado}
                                    </Badge>
                                  </div>
                                  
                                  {cita.notas && (
                                    <p className="text-xs text-gray-600 mt-2 bg-white/50 p-2 rounded-lg">
                                      {cita.notas}
                                    </p>
                                  )}
                                </div>
                              )}
                            </Draggable>
                          ))}
                        </div>
                      )}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            )
          })}
        </div>
      </DragDropContext>
    )
  }

  const renderWeekView = () => {
    const weekDates = getWeekDates(currentDate)

    return (
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-7 gap-4">
          {weekDates.map(date => {
            const citasDelDia = getCitasForDate(date)
            const fechaStr = date.toISOString().split('T')[0]
            
            return (
              <div key={date.toISOString()} className="space-y-2">
                <div className={cn(
                  "text-center p-3 rounded-xl shadow-sm border-2 cursor-pointer hover:shadow-md transition-all",
                  isToday(date) 
                    ? "bg-gradient-to-b from-green-600 to-green-700 text-white border-green-500 shadow-lg" 
                    : "bg-gradient-to-b from-gray-50 to-gray-100 border-gray-200 hover:border-green-300"
                )}
                onDoubleClick={() => handleDoubleClick(fechaStr)}
                >
                  <div className="text-xs font-semibold uppercase tracking-wide">
                    {getDayName(date).substring(0, 3)}
                  </div>
                  <div className="text-xl font-bold">
                    {date.getDate()}
                  </div>
                </div>
                
                <Droppable droppableId={fechaStr} direction="vertical">
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={cn(
                        "space-y-2 min-h-[400px] p-2 rounded-xl border-2 border-dashed transition-all",
                        snapshot.isDraggingOver 
                          ? "border-green-400 bg-green-50" 
                          : "border-gray-200 hover:border-green-300"
                      )}
                    >
                      {citasDelDia.map((cita, index) => (
                        <Draggable key={cita.id} draggableId={cita.id} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              className={cn(
                                "bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 rounded-lg p-3 text-xs shadow-sm hover:shadow-md transition-all cursor-move group",
                                snapshot.isDragging && "shadow-lg rotate-1 scale-105"
                              )}
                              onDoubleClick={() => onEditCita?.(cita)}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center space-x-1">
                                  <User className="h-3 w-3 text-green-600" />
                                  <div className="font-bold text-green-800">{cita.hora}</div>
                                </div>
                                <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      onEditCita?.(cita)
                                    }}
                                    className="h-4 w-4 p-0"
                                  >
                                    <Edit className="h-2 w-2" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      onDeleteCita?.(cita.id)
                                    }}
                                    className="h-4 w-4 p-0 text-red-600"
                                  >
                                    <Trash2 className="h-2 w-2" />
                                  </Button>
                                </div>
                              </div>
                              <div className="truncate font-semibold text-gray-900">{cita.pacienteNombre}</div>
                              <div className="text-gray-700 truncate">{cita.tipo}</div>
                              <Badge className={`${getEstadoColor(cita.estado)} text-xs mt-1`}>
                                {cita.estado}
                              </Badge>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                      
                      {citasDelDia.length === 0 && (
                        <div 
                          className="flex items-center justify-center h-32 text-gray-400 cursor-pointer hover:text-green-600 transition-colors"
                          onDoubleClick={() => handleDoubleClick(fechaStr)}
                        >
                          <div className="text-center">
                            <Plus className="h-8 w-8 mx-auto mb-2" />
                            <p className="text-xs">Doble clic para agendar</p>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </Droppable>
              </div>
            )
          })}
        </div>
      </DragDropContext>
    )
  }

  return (
    <Card className="seguros-card">
      <CardHeader className="bg-gradient-to-r from-green-50 to-yellow-50 border-b border-green-100">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center text-xl">
            <Calendar className="h-6 w-6 mr-3 text-green-600" />
            📅 Calendario Interactivo
            {realTimeUpdates && (
              <Badge variant="outline" className="ml-3 text-xs bg-green-100 text-green-800 border-green-300">
                <Sparkles className="h-3 w-3 mr-1 animate-pulse" />
                Tiempo Real
              </Badge>
            )}
          </CardTitle>
          <div className="flex space-x-2">
            <Button onClick={() => onNewCita?.()} className="seguros-button-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Cita
            </Button>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            {(['day', 'week', 'month'] as const).map(viewType => (
              <Button
                key={viewType}
                variant={view === viewType ? 'default' : 'outline'}
                size="sm"
                onClick={() => setView(viewType)}
                className={view === viewType ? 'seguros-button-primary' : 'hover:bg-green-50 border-green-200'}
              >
                {viewType === 'day' ? '📅 Día' : viewType === 'week' ? '📊 Semana' : '🗓️ Mes'}
              </Button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate('prev')} className="hover:bg-green-50 border-green-200">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="px-4 py-2 bg-white rounded-lg border-2 border-green-200 min-w-[200px] text-center shadow-sm">
              <span className="font-semibold text-green-800">
                {view === 'day' && formatDate(currentDate)}
                {view === 'week' && `Semana del ${formatDate(getWeekDates(currentDate)[0])}`}
                {view === 'month' && currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigateDate('next')} className="hover:bg-green-50 border-green-200">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Instrucciones de uso */}
        <div className="text-xs text-gray-600 bg-white/70 p-3 rounded-lg border border-green-100">
          <p className="font-semibold mb-1">💡 Instrucciones:</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            <span>🖱️ <strong>Doble clic:</strong> Crear/Editar cita</span>
            <span>🤏 <strong>Arrastrar:</strong> Mover cita</span>
            <span>⚡ <strong>Hover:</strong> Ver opciones</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        {view === 'day' && renderDayView()}
        {view === 'week' && renderWeekView()}
        {view === 'month' && (
          <div className="text-center py-12 text-gray-500">
            <Calendar className="h-20 w-20 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">Vista mensual en desarrollo</p>
            <p className="text-sm">Próximamente con funcionalidad completa</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
