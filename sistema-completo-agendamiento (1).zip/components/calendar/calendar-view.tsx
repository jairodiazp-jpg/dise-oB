'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, ChevronRight, Calendar, Plus } from 'lucide-react'
import { formatDate, getDayName, getWeekDates, getMonthDates, isToday } from '@/lib/utils/date-utils'
import { mockCitas, type Cita } from '@/lib/data/mock-data'
import { cn } from '@/lib/utils'

interface CalendarViewProps {
  profesionalId?: string
  empresaId?: string
  onNewCita?: () => void
}

export function CalendarView({ profesionalId, empresaId, onNewCita }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<'day' | 'week' | 'month'>('week')

  const filteredCitas = mockCitas.filter(cita => {
    if (profesionalId) return cita.profesionalId === profesionalId
    if (empresaId) return cita.empresaId === empresaId
    return true
  })

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate)
    switch (view) {
      case 'day':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1))
        break
      case 'week':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7))
        break
      case 'month':
        newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1))
        break
    }
    setCurrentDate(newDate)
  }

  const getCitasForDate = (date: Date): Cita[] => {
    const dateStr = date.toISOString().split('T')[0]
    return filteredCitas.filter(cita => cita.fecha === dateStr)
  }

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'confirmada':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'pendiente':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'cancelada':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'completada':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const renderDayView = () => {
    const citasDelDia = getCitasForDate(currentDate)
    const horas = Array.from({ length: 12 }, (_, i) => i + 8) // 8 AM to 7 PM

    return (
      <div className="space-y-4">
        {horas.map(hora => {
          const horaStr = `${hora.toString().padStart(2, '0')}:00`
          const citaEnHora = citasDelDia.find(cita => cita.hora.startsWith(hora.toString().padStart(2, '0')))

          return (
            <div key={hora} className="flex items-start space-x-4 min-h-[60px] border-b border-gray-100 pb-4">
              <div className="w-16 text-sm text-gray-500 font-medium pt-2">
                {horaStr}
              </div>
              <div className="flex-1">
                {citaEnHora ? (
                  <div className="bg-[#2E7D32] bg-opacity-10 border border-[#2E7D32] border-opacity-20 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold text-gray-900">{citaEnHora.pacienteNombre}</h4>
                        <p className="text-sm text-gray-600">{citaEnHora.tipo}</p>
                        <p className="text-xs text-gray-500">{citaEnHora.profesionalNombre}</p>
                      </div>
                      <Badge className={getEstadoColor(citaEnHora.estado)}>
                        {citaEnHora.estado}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      {citaEnHora.hora} - {citaEnHora.duracion} min
                    </div>
                    {citaEnHora.notas && (
                      <p className="text-sm text-gray-600 mt-2">{citaEnHora.notas}</p>
                    )}
                  </div>
                ) : (
                  <div className="text-gray-400 text-sm pt-2 cursor-pointer hover:text-[#2E7D32]" onClick={onNewCita}>
                    + Disponible para agendar
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  const renderWeekView = () => {
    const weekDates = getWeekDates(currentDate)

    return (
      <div className="grid grid-cols-7 gap-4">
        {weekDates.map(date => {
          const citasDelDia = getCitasForDate(date)
          return (
            <div key={date.toISOString()} className="space-y-2">
              <div className={cn(
                "text-center p-2 rounded-lg",
                isToday(date) ? "bg-[#2E7D32] text-white" : "bg-gray-50"
              )}>
                <div className="text-xs font-medium">
                  {getDayName(date).substring(0, 3)}
                </div>
                <div className="text-lg font-bold">
                  {date.getDate()}
                </div>
              </div>
              <div className="space-y-1 min-h-[200px]">
                {citasDelDia.map(cita => (
                  <div key={cita.id} className="bg-[#2E7D32] bg-opacity-10 border border-[#2E7D32] border-opacity-20 rounded p-2 text-xs">
                    <div className="font-medium">{cita.hora}</div>
                    <div className="truncate">{cita.pacienteNombre}</div>
                    <div className="text-gray-600 truncate">{cita.tipo}</div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  const renderMonthView = () => {
    const monthDates = getMonthDates(currentDate)
    const weeks = []
    
    for (let i = 0; i < monthDates.length; i += 7) {
      weeks.push(monthDates.slice(i, i + 7))
    }

    return (
      <div className="space-y-2">
        <div className="grid grid-cols-7 gap-2 mb-4">
          {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-500 p-2">
              {day}
            </div>
          ))}
        </div>
        {weeks.map((week, weekIndex) => (
          <div key={weekIndex} className="grid grid-cols-7 gap-2">
            {week.map(date => {
              const citasDelDia = getCitasForDate(date)
              return (
                <div key={date.toISOString()} className={cn(
                  "min-h-[100px] p-2 border rounded-lg cursor-pointer hover:bg-gray-50",
                  isToday(date) ? "bg-[#2E7D32] bg-opacity-10 border-[#2E7D32]" : "border-gray-200"
                )}>
                  <div className={cn(
                    "text-sm font-medium mb-1",
                    isToday(date) ? "text-[#2E7D32]" : "text-gray-900"
                  )}>
                    {date.getDate()}
                  </div>
                  <div className="space-y-1">
                    {citasDelDia.slice(0, 2).map(cita => (
                      <div key={cita.id} className="text-xs bg-[#2E7D32] bg-opacity-20 rounded px-1 py-0.5 truncate">
                        {cita.hora} {cita.pacienteNombre}
                      </div>
                    ))}
                    {citasDelDia.length > 2 && (
                      <div className="text-xs text-gray-500">
                        +{citasDelDia.length - 2} más
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    )
  }

  return (
    <Card className="seguros-card">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-[#2E7D32]" />
            Calendario de Citas
          </CardTitle>
          {onNewCita && (
            <Button onClick={onNewCita} className="seguros-button-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Cita
            </Button>
          )}
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            {(['day', 'week', 'month'] as const).map(viewType => (
              <Button
                key={viewType}
                variant={view === viewType ? 'default' : 'outline'}
                size="sm"
                onClick={() => setView(viewType)}
                className={view === viewType ? 'seguros-button-primary' : ''}
              >
                {viewType === 'day' ? 'Día' : viewType === 'week' ? 'Semana' : 'Mes'}
              </Button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate('prev')}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="px-4 py-2 bg-white rounded-lg border border-gray-200 min-w-[200px] text-center">
              <span className="font-medium">
                {view === 'day' && formatDate(currentDate)}
                {view === 'week' && `Semana del ${formatDate(getWeekDates(currentDate)[0])}`}
                {view === 'month' && currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigateDate('next')}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {view === 'day' && renderDayView()}
        {view === 'week' && renderWeekView()}
        {view === 'month' && renderMonthView()}
      </CardContent>
    </Card>
  )
}
