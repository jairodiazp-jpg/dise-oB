'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAuth } from '@/components/providers/auth-provider'
import { Loader2, Eye, EyeOff, Crown, Building2, UserCheck } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function LoginForm() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [userType, setUserType] = useState<'admin' | 'empresa' | 'profesional'>('profesional')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      await login(email, password, userType)
      toast({
        title: "¡Bienvenido!",
        description: "Has iniciado sesión exitosamente",
      })
    } catch (error) {
      toast({
        title: "Error de autenticación",
        description: "Credenciales inválidas o acceso denegado",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="userType" className="text-gray-700 font-medium">Tipo de Usuario</Label>
        <Select value={userType} onValueChange={(value: any) => setUserType(value)}>
          <SelectTrigger className="seguros-select h-12 shadow-sm">
            <SelectValue placeholder="Selecciona tu rol" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="admin">
              <div className="flex items-center space-x-3 py-1">
                <Crown className="h-5 w-5 text-yellow-600" />
                <span className="font-medium">Administrador Global</span>
              </div>
            </SelectItem>
            <SelectItem value="empresa">
              <div className="flex items-center space-x-3 py-1">
                <Building2 className="h-5 w-5 text-green-600" />
                <span className="font-medium">Empresa</span>
              </div>
            </SelectItem>
            <SelectItem value="profesional">
              <div className="flex items-center space-x-3 py-1">
                <UserCheck className="h-5 w-5 text-green-600" />
                <span className="font-medium">Profesional de Salud</span>
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email" className="text-gray-700 font-medium">Correo Electrónico</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="usuario@empresa.com"
          className="seguros-input h-12 shadow-sm"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password" className="text-gray-700 font-medium">Contraseña</Label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="seguros-input h-12 pr-12 shadow-sm"
            required
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4 text-gray-500" />
            ) : (
              <Eye className="h-4 w-4 text-gray-500" />
            )}
          </Button>
        </div>
      </div>

      <Button
        type="submit"
        className="w-full seguros-button-primary h-12 text-lg font-semibold"
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Iniciando sesión...
          </>
        ) : (
          'Iniciar Sesión'
        )}
      </Button>

      <div className="text-center text-sm text-gray-600 bg-gradient-to-r from-green-50 to-yellow-50 p-5 rounded-xl border border-green-100">
        <p className="font-semibold mb-3 text-gray-800 flex items-center justify-center">
          🔐 Credenciales de prueba
        </p>
        <div className="text-xs space-y-2">
          <div className="bg-white/70 p-2 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-yellow-700">👑 Admin Global:</span>
              <span className="text-green-700 font-mono">admin@segurosbolivar.com / admin123</span>
            </div>
          </div>
          <div className="bg-white/70 p-2 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700">🏢 Clínica Vida:</span>
              <span className="text-green-700 font-mono">admin@clinicavida.com / clinica123</span>
            </div>
          </div>
          <div className="bg-white/70 p-2 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700">🏥 Centro Médico:</span>
              <span className="text-green-700 font-mono">admin@centromedicosalud.com / centro123</span>
            </div>
          </div>
          <div className="bg-white/70 p-2 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700">🩺 Profesional:</span>
              <span className="text-green-700 font-mono">ana.gonzalez@clinicavida.com / doctor123</span>
            </div>
          </div>
        </div>
      </div>
    </form>
  )
}
