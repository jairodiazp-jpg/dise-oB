'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { MessageCircle, Send, Bot, User, HelpCircle, Key, Phone, Mail, Clock } from 'lucide-react'

interface ChatMessage {
  id: string
  type: 'user' | 'bot'
  message: string
  timestamp: Date
  options?: string[]
}

export function ChatbotSupport() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      message: '¡Hola! 👋 Soy el asistente virtual de Seguros Bolívar. ¿En qué puedo ayudarte hoy?',
      timestamp: new Date(),
      options: [
        'Recuperar contraseña',
        'Problemas de acceso',
        'Información del sistema',
        'Contactar soporte humano'
      ]
    }
  ])
  const [currentMessage, setCurrentMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)

  const botResponses = {
    'recuperar contraseña': {
      message: '🔑 Para recuperar tu contraseña, necesito algunos datos:\n\n1. Confirma tu correo electrónico\n2. Selecciona tu tipo de usuario\n3. Te enviaremos un enlace de recuperación\n\n¿Cuál es tu correo electrónico registrado?',
      options: ['admin@segurosbolivar.com', 'Otro correo', 'Contactar administrador']
    },
    'problemas de acceso': {
      message: '🚪 Veo que tienes problemas para acceder. Las causas más comunes son:\n\n• Credenciales incorrectas\n• Cuenta bloqueada\n• Problemas de conexión\n• Tipo de usuario incorrecto\n\n¿Qué mensaje de error ves?',
      options: ['Credenciales inválidas', 'Cuenta bloqueada', 'No recuerdo mi usuario', 'Otro problema']
    },
    'información del sistema': {
      message: '📋 Sistema de Agendamiento Médico - Seguros Bolívar\n\n✅ Funcionalidades principales:\n• Gestión de citas médicas\n• Calendarios interactivos\n• Dashboards en tiempo real\n• Gestión de profesionales\n• Reportes avanzados\n\n¿Qué información específica necesitas?',
      options: ['Cómo usar el calendario', 'Gestión de citas', 'Reportes', 'Configuración']
    },
    'contactar soporte humano': {
      message: '👨‍💼 Te conectaré con nuestro equipo de soporte humano.\n\n📞 Opciones de contacto:\n• Teléfono: +57 1 234-5678\n• Email: soporte@segurosbolivar.com\n• Chat en vivo: Lun-Vie 8AM-6PM\n\n¿Prefieres que te transfiera al chat en vivo?',
      options: ['Sí, transferir ahora', 'Llamar por teléfono', 'Enviar email', 'Volver al menú']
    }
  }

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return

    // Agregar mensaje del usuario
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      message: message,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setCurrentMessage('')
    setIsTyping(true)

    // Simular respuesta del bot
    setTimeout(() => {
      const lowerMessage = message.toLowerCase()
      let botResponse = botResponses['información del sistema'] // respuesta por defecto

      // Buscar respuesta apropiada
      Object.entries(botResponses).forEach(([key, response]) => {
        if (lowerMessage.includes(key.toLowerCase()) || 
            key.toLowerCase().includes(lowerMessage)) {
          botResponse = response
        }
      })

      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        message: botResponse.message,
        timestamp: new Date(),
        options: botResponse.options
      }

      setMessages(prev => [...prev, botMessage])
      setIsTyping(false)
    }, 1500)
  }

  const handleOptionClick = (option: string) => {
    handleSendMessage(option)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full seguros-button-primary shadow-lg hover:shadow-xl z-50"
          size="sm"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[500px] h-[600px] p-0 seguros-card">
        <DialogHeader className="p-6 pb-4 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-t-xl">
          <DialogTitle className="flex items-center text-xl">
            <Bot className="h-6 w-6 mr-3" />
            🤖 Asistente Virtual
          </DialogTitle>
          <DialogDescription className="text-green-100">
            Soporte 24/7 para Seguros Bolívar
            <Badge className="ml-2 bg-green-500 text-white">
              <Clock className="h-3 w-3 mr-1" />
              En línea
            </Badge>
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col h-[500px]">
          {/* Área de mensajes */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex items-start space-x-2 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.type === 'user' 
                        ? 'bg-green-600 text-white' 
                        : 'bg-gradient-to-r from-green-100 to-yellow-100 text-green-700'
                    }`}>
                      {message.type === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </div>
                    
                    <div className={`rounded-xl p-3 ${
                      message.type === 'user'
                        ? 'bg-green-600 text-white'
                        : 'bg-gradient-to-r from-gray-50 to-gray-100 text-gray-800 border border-gray-200'
                    }`}>
                      <p className="text-sm whitespace-pre-line">{message.message}</p>
                      <p className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-green-100' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                      
                      {/* Opciones de respuesta rápida */}
                      {message.options && (
                        <div className="mt-3 space-y-1">
                          {message.options.map((option, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              onClick={() => handleOptionClick(option)}
                              className="w-full text-left justify-start text-xs hover:bg-green-50 border-green-200"
                            >
                              {option}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Indicador de escritura */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-green-100 to-yellow-100 flex items-center justify-center">
                      <Bot className="h-4 w-4 text-green-700" />
                    </div>
                    <div className="bg-gray-100 rounded-xl p-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Área de entrada */}
          <div className="p-4 border-t border-gray-200 bg-gray-50">
            <div className="flex space-x-2">
              <Input
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                placeholder="Escribe tu mensaje..."
                className="flex-1 seguros-input"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSendMessage(currentMessage)
                  }
                }}
              />
              <Button 
                onClick={() => handleSendMessage(currentMessage)}
                className="seguros-button-primary"
                disabled={!currentMessage.trim() || isTyping}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Opciones rápidas */}
            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleOptionClick('Recuperar contraseña')}
                className="text-xs hover:bg-green-50 border-green-200"
              >
                <Key className="h-3 w-3 mr-1" />
                Recuperar contraseña
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleOptionClick('Contactar soporte humano')}
                className="text-xs hover:bg-green-50 border-green-200"
              >
                <Phone className="h-3 w-3 mr-1" />
                Soporte humano
              </Button>
            </div>
          </div>
        </div>

        {/* Footer con información de contacto */}
        <div className="p-4 bg-gradient-to-r from-green-50 to-yellow-50 border-t border-green-100 rounded-b-xl">
          <div className="flex items-center justify-between text-xs text-gray-600">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Phone className="h-3 w-3 mr-1 text-green-600" />
                +57 1 234-5678
              </div>
              <div className="flex items-center">
                <Mail className="h-3 w-3 mr-1 text-green-600" />
                soporte@segurosbolivar.com
              </div>
            </div>
            <Badge variant="outline" className="text-green-700 border-green-300">
              24/7 Disponible
            </Badge>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
