'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useAuth } from '@/components/providers/auth-provider'
import { Loader2, Eye, EyeOff, Crown, Building2, UserCheck, Shield, Key, Mail, AlertCircle, CheckCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function SecureLogin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [userType, setUserType] = useState<'admin' | 'empresa' | 'profesional'>('profesional')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [showRecovery, setShowRecovery] = useState(false)
  const [recoveryEmail, setRecoveryEmail] = useState('')
  const [recoveryStep, setRecoveryStep] = useState<'email' | 'code' | 'success'>('email')
  const [verificationCode, setVerificationCode] = useState('')
  const { login } = useAuth()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      await login(email, password, userType)
      toast({
        title: "🎉 ¡Bienvenido!",
        description: "Has iniciado sesión exitosamente",
      })
    } catch (error) {
      toast({
        title: "🚫 Error de autenticación",
        description: "Credenciales inválidas o acceso denegado",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePasswordRecovery = async () => {
    if (recoveryStep === 'email') {
      if (!recoveryEmail) {
        toast({
          title: "❌ Error",
          description: "Por favor ingresa tu correo electrónico",
          variant: "destructive",
        })
        return
      }

      // Simular envío de código
      setTimeout(() => {
        setRecoveryStep('code')
        toast({
          title: "📧 Código enviado",
          description: "Revisa tu correo electrónico para el código de verificación",
        })
      }, 1000)
    } else if (recoveryStep === 'code') {
      if (verificationCode.length !== 6) {
        toast({
          title: "❌ Error",
          description: "El código debe tener 6 dígitos",
          variant: "destructive",
        })
        return
      }

      // Simular verificación
      setTimeout(() => {
        setRecoveryStep('success')
        toast({
          title: "✅ Contraseña restablecida",
          description: "Tu contraseña ha sido restablecida exitosamente",
        })
      }, 1000)
    }
  }

  const resetRecoveryForm = () => {
    setRecoveryEmail('')
    setVerificationCode('')
    setRecoveryStep('email')
    setShowRecovery(false)
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Indicador de seguridad */}
        <div className="flex items-center justify-center space-x-2 p-3 bg-gradient-to-r from-green-50 to-yellow-50 rounded-lg border border-green-200">
          <Shield className="h-5 w-5 text-green-600" />
          <span className="text-sm font-medium text-green-800">🔒 Conexión Segura SSL</span>
        </div>

        <div className="space-y-2">
          <Label htmlFor="userType" className="text-gray-700 font-medium">Tipo de Usuario</Label>
          <Select value={userType} onValueChange={(value: any) => setUserType(value)}>
            <SelectTrigger className="seguros-select h-12 shadow-sm">
              <SelectValue placeholder="Selecciona tu rol" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin">
                <div className="flex items-center space-x-3 py-1">
                  <Crown className="h-5 w-5 text-yellow-600" />
                  <span className="font-medium">👑 Administrador Global</span>
                </div>
              </SelectItem>
              <SelectItem value="empresa">
                <div className="flex items-center space-x-3 py-1">
                  <Building2 className="h-5 w-5 text-green-600" />
                  <span className="font-medium">🏢 Empresa</span>
                </div>
              </SelectItem>
              <SelectItem value="profesional">
                <div className="flex items-center space-x-3 py-1">
                  <UserCheck className="h-5 w-5 text-green-600" />
                  <span className="font-medium">🩺 Profesional de Salud</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-gray-700 font-medium">Correo Electrónico</Label>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="usuario@empresa.com"
            className="seguros-input h-12 shadow-sm"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password" className="text-gray-700 font-medium">Contraseña</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="seguros-input h-12 pr-12 shadow-sm"
              required
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4 text-gray-500" />
              ) : (
                <Eye className="h-4 w-4 text-gray-500" />
              )}
            </Button>
          </div>
        </div>

        {/* Enlace de recuperación */}
        <div className="text-center">
          <Dialog open={showRecovery} onOpenChange={setShowRecovery}>
            <DialogTrigger asChild>
              <Button variant="link" className="text-green-600 hover:text-green-700 font-medium">
                <Key className="h-4 w-4 mr-2" />
                ¿Olvidaste tu contraseña?
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[400px] seguros-card">
              <DialogHeader>
                <DialogTitle className="flex items-center">
                  <Key className="h-5 w-5 mr-2 text-green-600" />
                  🔑 Recuperar Contraseña
                </DialogTitle>
                <DialogDescription>
                  {recoveryStep === 'email' && "Ingresa tu correo para recibir el código de verificación"}
                  {recoveryStep === 'code' && "Ingresa el código de 6 dígitos enviado a tu correo"}
                  {recoveryStep === 'success' && "Tu contraseña ha sido restablecida exitosamente"}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {recoveryStep === 'email' && (
                  <div className="space-y-2">
                    <Label htmlFor="recoveryEmail">Correo Electrónico</Label>
                    <Input
                      id="recoveryEmail"
                      type="email"
                      value={recoveryEmail}
                      onChange={(e) => setRecoveryEmail(e.target.value)}
                      placeholder="tu@email.com"
                      className="seguros-input"
                    />
                  </div>
                )}

                {recoveryStep === 'code' && (
                  <div className="space-y-2">
                    <Label htmlFor="verificationCode">Código de Verificación</Label>
                    <Input
                      id="verificationCode"
                      type="text"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      placeholder="123456"
                      className="seguros-input text-center text-lg tracking-widest"
                      maxLength={6}
                    />
                    <p className="text-xs text-gray-600 text-center">
                      Código enviado a: {recoveryEmail}
                    </p>
                  </div>
                )}

                {recoveryStep === 'success' && (
                  <div className="text-center py-6">
                    <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                    <p className="text-green-800 font-medium">
                      ✅ ¡Contraseña restablecida exitosamente!
                    </p>
                    <p className="text-sm text-gray-600 mt-2">
                      Revisa tu correo para la nueva contraseña temporal
                    </p>
                  </div>
                )}
              </div>

              <DialogFooter>
                {recoveryStep !== 'success' ? (
                  <>
                    <Button variant="outline" onClick={resetRecoveryForm}>
                      Cancelar
                    </Button>
                    <Button onClick={handlePasswordRecovery} className="seguros-button-primary">
                      {recoveryStep === 'email' ? (
                        <>
                          <Mail className="h-4 w-4 mr-2" />
                          Enviar Código
                        </>
                      ) : (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Verificar Código
                        </>
                      )}
                    </Button>
                  </>
                ) : (
                  <Button onClick={resetRecoveryForm} className="w-full seguros-button-primary">
                    Cerrar
                  </Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Button
          type="submit"
          className="w-full seguros-button-primary h-12 text-lg font-semibold"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Iniciando sesión...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-5 w-5" />
              Iniciar Sesión Segura
            </>
          )}
        </Button>

        {/* Información de seguridad */}
        <div className="text-center text-xs text-gray-600 bg-gradient-to-r from-green-50 to-yellow-50 p-4 rounded-xl border border-green-100">
          <div className="flex items-center justify-center mb-2">
            <AlertCircle className="h-4 w-4 mr-2 text-green-600" />
            <span className="font-semibold text-green-800">🔐 Información de Seguridad</span>
          </div>
          <p className="mb-2">
            • Conexión encriptada SSL/TLS<br/>
            • Autenticación de dos factores disponible<br/>
            • Sesiones seguras con timeout automático
          </p>
        </div>
      </form>

      {/* Credenciales de prueba mejoradas */}
      <div className="text-center text-sm text-gray-600 bg-gradient-to-r from-green-50 to-yellow-50 p-5 rounded-xl border border-green-100">
        <p className="font-semibold mb-3 text-gray-800 flex items-center justify-center">
          🔐 Credenciales de prueba - Ambiente de desarrollo
        </p>
        <div className="text-xs space-y-2">
          <div className="bg-white/70 p-3 rounded-lg shadow-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium text-yellow-700 flex items-center">
                <Crown className="h-4 w-4 mr-2" />
                👑 Admin Global:
              </span>
              <span className="text-green-700 font-mono bg-green-100 px-2 py-1 rounded">
                admin@segurosbolivar.com / admin123
              </span>
            </div>
          </div>
          <div className="bg-white/70 p-3 rounded-lg shadow-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700 flex items-center">
                <Building2 className="h-4 w-4 mr-2" />
                🏢 Clínica Vida:
              </span>
              <span className="text-green-700 font-mono bg-green-100 px-2 py-1 rounded">
                admin@clinicavida.com / clinica123
              </span>
            </div>
          </div>
          <div className="bg-white/70 p-3 rounded-lg shadow-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700 flex items-center">
                <Building2 className="h-4 w-4 mr-2" />
                🏥 Centro Médico:
              </span>
              <span className="text-green-700 font-mono bg-green-100 px-2 py-1 rounded">
                admin@centromedicosalud.com / centro123
              </span>
            </div>
          </div>
          <div className="bg-white/70 p-3 rounded-lg shadow-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700 flex items-center">
                <UserCheck className="h-4 w-4 mr-2" />
                🩺 Profesional:
              </span>
              <span className="text-green-700 font-mono bg-green-100 px-2 py-1 rounded">
                ana.gonzalez@clinicavida.com / doctor123
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
