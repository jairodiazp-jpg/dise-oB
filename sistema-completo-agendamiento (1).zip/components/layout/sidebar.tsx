'use client'

import { useState } from 'react'
import { useAuth } from '@/components/providers/auth-provider'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Calendar, Users, Building2, BarChart3, Clock, Bell, Settings, LogOut, Menu, X, FileText, Activity } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

interface SidebarProps {
  className?: string
}

export function Sidebar({ className }: SidebarProps) {
  const { user, logout } = useAuth()
  const pathname = usePathname()
  const [isCollapsed, setIsCollapsed] = useState(false)

  const getMenuItems = () => {
    const baseUrl = `/${user?.role}`
    
    switch (user?.role) {
      case 'admin':
        return [
          { icon: BarChart3, label: 'Dashboard', href: `${baseUrl}/dashboard` },
          { icon: Building2, label: 'Empresas', href: `${baseUrl}/empresas` },
          { icon: Users, label: 'Profesionales', href: `${baseUrl}/profesionales` },
          { icon: Calendar, label: 'Citas', href: `${baseUrl}/citas` },
          { icon: Clock, label: 'Horas Trabajadas', href: `${baseUrl}/horas` },
          { icon: FileText, label: 'Reportes', href: `${baseUrl}/reportes` },
          { icon: Activity, label: 'Logs', href: `${baseUrl}/logs` },
          { icon: Bell, label: 'Notificaciones', href: `${baseUrl}/notificaciones` },
        ]
      case 'empresa':
        return [
          { icon: BarChart3, label: 'Dashboard', href: `${baseUrl}/dashboard` },
          { icon: Users, label: 'Profesionales', href: `${baseUrl}/profesionales` },
          { icon: Calendar, label: 'Citas', href: `${baseUrl}/citas` },
          { icon: Clock, label: 'Horas Trabajadas', href: `${baseUrl}/horas` },
          { icon: FileText, label: 'Reportes', href: `${baseUrl}/reportes` },
          { icon: Bell, label: 'Notificaciones', href: `${baseUrl}/notificaciones` },
        ]
      case 'profesional':
        return [
          { icon: BarChart3, label: 'Dashboard', href: `${baseUrl}/dashboard` },
          { icon: Calendar, label: 'Mi Agenda', href: `${baseUrl}/agenda` },
          { icon: Clock, label: 'Mis Horas', href: `${baseUrl}/horas` },
          { icon: Bell, label: 'Notificaciones', href: `${baseUrl}/notificaciones` },
        ]
      default:
        return []
    }
  }

  const menuItems = getMenuItems()

  return (
    <div className={cn(
      "flex flex-col h-full bg-white border-r border-gray-200",
      isCollapsed ? "w-16" : "w-64",
      className
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        {!isCollapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-green-700 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">SB</span>
            </div>
            <div>
              <h2 className="font-semibold text-sm">Seguros Bolívar</h2>
              <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="h-8 w-8 p-0"
        >
          {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
        </Button>
      </div>

      {/* User Info */}
      {!isCollapsed && (
        <div className="p-4 bg-gray-50">
          <div className="text-sm font-medium text-gray-900">{user?.name}</div>
          <div className="text-xs text-gray-500">{user?.email}</div>
          {user?.especialidad && (
            <div className="text-xs text-green-700 font-medium mt-1">
              {user.especialidad}
            </div>
          )}
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-1">
          {menuItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    isActive && "bg-green-700 text-white hover:bg-green-800",
                    isCollapsed && "px-2"
                  )}
                >
                  <item.icon className={cn("h-4 w-4", !isCollapsed && "mr-2")} />
                  {!isCollapsed && item.label}
                </Button>
              </Link>
            )
          })}
        </nav>
      </ScrollArea>

      <Separator />

      {/* Footer */}
      <div className="p-3">
        <Button
          variant="ghost"
          onClick={logout}
          className={cn(
            "w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50",
            isCollapsed && "px-2"
          )}
        >
          <LogOut className={cn("h-4 w-4", !isCollapsed && "mr-2")} />
          {!isCollapsed && "Cerrar Sesión"}
        </Button>
      </div>
    </div>
  )
}
