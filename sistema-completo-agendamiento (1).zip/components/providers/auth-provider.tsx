'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'empresa' | 'profesional'
  empresaId?: string
  empresaNombre?: string
  especialidad?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string, userType: string) => Promise<void>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Datos de prueba con usuarios específicos por empresa
const mockUsers = [
  // Administrador Global
  {
    id: '1',
    email: 'admin@segurosbolivar.com',
    password: 'admin123',
    name: 'Administrador Global',
    role: 'admin' as const,
  },
  
  // Usuarios de Empresas
  {
    id: '2',
    email: 'admin@clinicavida.com',
    password: 'clinica123',
    name: 'Administrador Clínica Vida',
    role: 'empresa' as const,
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
  },
  {
    id: '3',
    email: 'gerente@clinicavida.com',
    password: 'gerente123',
    name: 'Gerente Clínica Vida',
    role: 'empresa' as const,
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
  },
  {
    id: '4',
    email: 'admin@centromedicosalud.com',
    password: 'centro123',
    name: 'Administrador Centro Médico Salud',
    role: 'empresa' as const,
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
  },
  {
    id: '5',
    email: 'director@centromedicosalud.com',
    password: 'director123',
    name: 'Director Centro Médico Salud',
    role: 'empresa' as const,
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
  },
  {
    id: '6',
    email: 'admin@hospitalsanjose.com',
    password: 'hospital123',
    name: 'Administrador Hospital San José',
    role: 'empresa' as const,
    empresaId: '3',
    empresaNombre: 'Hospital San José',
  },
  
  // Profesionales de Clínica Vida
  {
    id: '7',
    email: 'ana.gonzalez@clinicavida.com',
    password: 'doctor123',
    name: 'Dra. Ana María González',
    role: 'profesional' as const,
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    especialidad: 'Cardiología',
  },
  {
    id: '8',
    email: 'carlos.rodriguez@clinicavida.com',
    password: 'doctor123',
    name: 'Dr. Carlos Rodríguez',
    role: 'profesional' as const,
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    especialidad: 'Neurología',
  },
  {
    id: '9',
    email: 'laura.martinez@clinicavida.com',
    password: 'doctor123',
    name: 'Dra. Laura Martínez',
    role: 'profesional' as const,
    empresaId: '1',
    empresaNombre: 'Clínica Vida',
    especialidad: 'Pediatría',
  },
  
  // Profesionales de Centro Médico Salud
  {
    id: '10',
    email: 'miguel.torres@centromedicosalud.com',
    password: 'doctor123',
    name: 'Dr. Miguel Torres',
    role: 'profesional' as const,
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
    especialidad: 'Ortopedia',
  },
  {
    id: '11',
    email: 'sofia.herrera@centromedicosalud.com',
    password: 'doctor123',
    name: 'Dra. Sofía Herrera',
    role: 'profesional' as const,
    empresaId: '2',
    empresaNombre: 'Centro Médico Salud',
    especialidad: 'Ginecología',
  },
  
  // Profesionales de Hospital San José
  {
    id: '12',
    email: 'ricardo.lopez@hospitalsanjose.com',
    password: 'doctor123',
    name: 'Dr. Ricardo López',
    role: 'profesional' as const,
    empresaId: '3',
    empresaNombre: 'Hospital San José',
    especialidad: 'Cirugía General',
  },
]

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('auth-token')
    if (token) {
      try {
        const userData = JSON.parse(atob(token))
        setUser(userData)
      } catch (error) {
        localStorage.removeItem('auth-token')
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string, userType: string) => {
    const mockUser = mockUsers.find(
      u => u.email === email && u.password === password && u.role === userType
    )

    if (!mockUser) {
      throw new Error('Credenciales inválidas')
    }

    const userData: User = {
      id: mockUser.id,
      email: mockUser.email,
      name: mockUser.name,
      role: mockUser.role,
      empresaId: mockUser.empresaId,
      empresaNombre: mockUser.empresaNombre,
      especialidad: mockUser.especialidad,
    }

    setUser(userData)
    localStorage.setItem('auth-token', btoa(JSON.stringify(userData)))
    
    // Redirigir según el rol
    switch (userData.role) {
      case 'admin':
        router.push('/admin/dashboard')
        break
      case 'empresa':
        router.push('/empresa/dashboard')
        break
      case 'profesional':
        router.push('/profesional/dashboard')
        break
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('auth-token')
    router.push('/')
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export { AuthContext }
