'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Calendar, Users, Clock, TrendingUp, AlertTriangle, CheckCircle, XCircle, RotateCcw, Sparkles, Activity } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts'
import { useAuth } from '@/components/providers/auth-provider'
import { mockCitas, mockProfesionales } from '@/lib/data/mock-data'

interface DashboardMetrics {
  totalCitas: number
  citasHoy: number
  citasConfirmadas: number
  citasPendientes: number
  citasCanceladas: number
  citasReprogramadas: number
  tiempoPromedioAtencion: number
  profesionalesActivos: number
  eficienciaGeneral: number
}

interface CitasPorProfesional {
  profesional: string
  citas: number
  completadas: number
  pendientes: number
  canceladas: number
}

interface IntelligentDashboardProps {
  empresaId?: string
  profesionalId?: string
  realTimeUpdates?: boolean
}

export function IntelligentDashboard({ empresaId, profesionalId, realTimeUpdates = true }: IntelligentDashboardProps) {
  const { user } = useAuth()
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalCitas: 0,
    citasHoy: 0,
    citasConfirmadas: 0,
    citasPendientes: 0,
    citasCanceladas: 0,
    citasReprogramadas: 0,
    tiempoPromedioAtencion: 0,
    profesionalesActivos: 0,
    eficienciaGeneral: 0
  })
  const [refreshKey, setRefreshKey] = useState(0)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Datos para gráficos
  const citasPorDia = [
    { dia: 'Lun', citas: 12, completadas: 11, canceladas: 1 },
    { dia: 'Mar', citas: 15, completadas: 14, canceladas: 1 },
    { dia: 'Mié', citas: 18, completadas: 16, canceladas: 2 },
    { dia: 'Jue', citas: 14, completadas: 13, canceladas: 1 },
    { dia: 'Vie', citas: 20, completadas: 18, canceladas: 2 },
    { dia: 'Sáb', citas: 8, completadas: 8, canceladas: 0 },
    { dia: 'Dom', citas: 5, completadas: 5, canceladas: 0 },
  ]

  const tiemposAtencion = [
    { hora: '08:00', tiempo: 25 },
    { hora: '09:00', tiempo: 30 },
    { hora: '10:00', tiempo: 28 },
    { hora: '11:00', tiempo: 32 },
    { hora: '12:00', tiempo: 35 },
    { hora: '14:00', tiempo: 29 },
    { hora: '15:00', tiempo: 27 },
    { hora: '16:00', tiempo: 31 },
  ]

  const estadoCitas = [
    { name: 'Confirmadas', value: 65, color: '#2E7D32' },
    { name: 'Pendientes', value: 20, color: '#FBC02D' },
    { name: 'Canceladas', value: 10, color: '#D32F2F' },
    { name: 'Reprogramadas', value: 5, color: '#FF9800' },
  ]

  // Simulación de tiempo real
  useEffect(() => {
    if (!realTimeUpdates) return

    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1)
      setLastUpdate(new Date())
      
      // Simular cambios en métricas
      setMetrics(prev => ({
        ...prev,
        totalCitas: prev.totalCitas + Math.floor(Math.random() * 3),
        citasHoy: Math.floor(Math.random() * 25) + 15,
        citasConfirmadas: Math.floor(Math.random() * 20) + 10,
        citasPendientes: Math.floor(Math.random() * 8) + 2,
        citasCanceladas: Math.floor(Math.random() * 3) + 1,
        citasReprogramadas: Math.floor(Math.random() * 2) + 1,
        tiempoPromedioAtencion: Math.floor(Math.random() * 10) + 25,
        profesionalesActivos: mockProfesionales.filter(p => p.activo).length,
        eficienciaGeneral: Math.floor(Math.random() * 10) + 85
      }))
    }, 10000) // Actualizar cada 10 segundos

    return () => clearInterval(interval)
  }, [realTimeUpdates])

  // Inicializar métricas
  useEffect(() => {
    const filteredCitas = mockCitas.filter(cita => {
      if (profesionalId) return cita.profesionalId === profesionalId
      if (empresaId) return cita.empresaId === empresaId
      return true
    })

    const today = new Date().toISOString().split('T')[0]
    const citasHoy = filteredCitas.filter(cita => cita.fecha === today)

    setMetrics({
      totalCitas: filteredCitas.length,
      citasHoy: citasHoy.length,
      citasConfirmadas: filteredCitas.filter(c => c.estado === 'confirmada').length,
      citasPendientes: filteredCitas.filter(c => c.estado === 'pendiente').length,
      citasCanceladas: filteredCitas.filter(c => c.estado === 'cancelada').length,
      citasReprogramadas: Math.floor(filteredCitas.length * 0.1),
      tiempoPromedioAtencion: 28,
      profesionalesActivos: mockProfesionales.filter(p => p.activo && (!empresaId || p.empresaId === empresaId)).length,
      eficienciaGeneral: 92
    })
  }, [empresaId, profesionalId])

  const citasPorProfesional: CitasPorProfesional[] = mockProfesionales
    .filter(p => !empresaId || p.empresaId === empresaId)
    .map(profesional => {
      const citasProfesional = mockCitas.filter(c => c.profesionalId === profesional.id)
      return {
        profesional: profesional.nombre.split(' ').slice(-1)[0], // Solo apellido
        citas: citasProfesional.length,
        completadas: citasProfesional.filter(c => c.estado === 'completada').length,
        pendientes: citasProfesional.filter(c => c.estado === 'pendiente').length,
        canceladas: citasProfesional.filter(c => c.estado === 'cancelada').length,
      }
    })

  return (
    <div className="space-y-6">
      {/* Header con tiempo real */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <Activity className="h-6 w-6 mr-2 text-green-600" />
            📊 Dashboard Inteligente
          </h2>
          <p className="text-gray-600">Métricas en tiempo real de tu {user?.role === 'admin' ? 'sistema' : user?.role === 'empresa' ? 'empresa' : 'agenda'}</p>
        </div>
        {realTimeUpdates && (
          <div className="text-right">
            <Badge className="bg-green-100 text-green-800 border-green-300">
              <Sparkles className="h-3 w-3 mr-1 animate-pulse" />
              Tiempo Real
            </Badge>
            <p className="text-xs text-gray-500 mt-1">
              Última actualización: {lastUpdate.toLocaleTimeString()}
            </p>
          </div>
        )}
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="seguros-card bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Citas Hoy</CardTitle>
            <Calendar className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-900">{metrics.citasHoy}</div>
            <p className="text-xs text-green-700 flex items-center mt-1">
              <TrendingUp className="h-3 w-3 mr-1" />
              +12% vs ayer
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-yellow-800">Tiempo Promedio</CardTitle>
            <Clock className="h-5 w-5 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-900">{metrics.tiempoPromedioAtencion} min</div>
            <p className="text-xs text-yellow-700 flex items-center mt-1">
              <TrendingUp className="h-3 w-3 mr-1" />
              Óptimo
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Profesionales Activos</CardTitle>
            <Users className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-900">{metrics.profesionalesActivos}</div>
            <p className="text-xs text-blue-700 flex items-center mt-1">
              <CheckCircle className="h-3 w-3 mr-1" />
              100% disponibles
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Eficiencia General</CardTitle>
            <TrendingUp className="h-5 w-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-900">{metrics.eficienciaGeneral}%</div>
            <Progress value={metrics.eficienciaGeneral} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Gráficos principales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Citas por día */}
        <Card className="seguros-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart className="h-5 w-5 mr-2 text-green-600" />
              📈 Citas por Día
            </CardTitle>
            <CardDescription>Comparación de citas programadas vs completadas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={citasPorDia}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis dataKey="dia" />
                <YAxis />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#f8f9fa', 
                    border: '1px solid #2E7D32',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="citas" fill="#2E7D32" name="Programadas" radius={[4, 4, 0, 0]} />
                <Bar dataKey="completadas" fill="#FBC02D" name="Completadas" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Estado de citas */}
        <Card className="seguros-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 mr-2 text-green-600" />
              🥧 Estado de Citas
            </CardTitle>
            <CardDescription>Distribución actual del estado de las citas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={estadoCitas}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                  labelLine={false}
                >
                  {estadoCitas.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Métricas detalladas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tiempos de atención */}
        <Card className="seguros-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="h-5 w-5 mr-2 text-green-600" />
              ⏱️ Tiempos de Atención
            </CardTitle>
            <CardDescription>Tiempo promedio de atención por hora</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={tiemposAtencion}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hora" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="tiempo" 
                  stroke="#2E7D32" 
                  fill="#2E7D32" 
                  fillOpacity={0.3}
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Rendimiento por profesional */}
        <Card className="seguros-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-green-600" />
              👥 Rendimiento por Profesional
            </CardTitle>
            <CardDescription>Citas por profesional esta semana</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {citasPorProfesional.slice(0, 5).map((profesional, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gradient-to-r from-green-50 to-yellow-50 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-bold">
                      {profesional.profesional.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Dr. {profesional.profesional}</p>
                      <p className="text-sm text-gray-600">{profesional.citas} citas totales</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex space-x-2">
                      <Badge className="bg-green-100 text-green-800 text-xs">
                        ✅ {profesional.completadas}
                      </Badge>
                      <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                        ⏳ {profesional.pendientes}
                      </Badge>
                      {profesional.canceladas > 0 && (
                        <Badge className="bg-red-100 text-red-800 text-xs">
                          ❌ {profesional.canceladas}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas y notificaciones */}
      <Card className="seguros-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-yellow-600" />
            🚨 Alertas y Notificaciones
          </CardTitle>
          <CardDescription>Eventos que requieren atención</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-yellow-600" />
              <div>
                <p className="font-semibold text-yellow-800">Citas sin confirmar</p>
                <p className="text-sm text-yellow-700">{metrics.citasPendientes} pendientes</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-4 bg-red-50 border border-red-200 rounded-lg">
              <XCircle className="h-6 w-6 text-red-600" />
              <div>
                <p className="font-semibold text-red-800">Cancelaciones</p>
                <p className="text-sm text-red-700">{metrics.citasCanceladas} esta semana</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <RotateCcw className="h-6 w-6 text-orange-600" />
              <div>
                <p className="font-semibold text-orange-800">Reprogramaciones</p>
                <p className="text-sm text-orange-700">{metrics.citasReprogramadas} este mes</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
