'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { FileText, Download, Calendar, Users, Clock, Building2 } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { useToast } from '@/hooks/use-toast'
import { mockEmpresas, mockProfesionales } from '@/lib/data/mock-data'

export function ReportGenerator() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [reportConfig, setReportConfig] = useState({
    tipo: '',
    formato: 'pdf',
    fechaInicio: '',
    fechaFin: '',
    empresaId: user?.role === 'empresa' ? user.empresaId : '',
    profesionalId: user?.role === 'profesional' ? user.id : '',
    incluirDetalles: true,
    incluirGraficas: true,
    incluirResumen: true
  })

  const tiposReporte = [
    { value: 'citas', label: 'Reporte de Citas', icon: Calendar },
    { value: 'horas', label: 'Reporte de Horas Trabajadas', icon: Clock },
    { value: 'profesionales', label: 'Reporte de Profesionales', icon: Users },
    { value: 'empresas', label: 'Reporte de Empresas', icon: Building2 },
  ]

  const empresasFiltradas = user?.role === 'admin' ? mockEmpresas : 
    mockEmpresas.filter(e => e.id === user?.empresaId)

  const profesionalesFiltrados = user?.role === 'admin' ? mockProfesionales :
    user?.role === 'empresa' ? mockProfesionales.filter(p => p.empresaId === user.empresaId) :
    mockProfesionales.filter(p => p.id === user?.id)

  const handleGenerate = async () => {
    if (!reportConfig.tipo) {
      toast({
        title: "Error",
        description: "Por favor selecciona un tipo de reporte",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      // Simular generación de reporte
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      toast({
        title: "Reporte generado exitosamente",
        description: `El reporte de ${tiposReporte.find(t => t.value === reportConfig.tipo)?.label} ha sido generado`,
      })

      // Simular descarga
      const blob = new Blob(['Contenido del reporte simulado'], { type: 'application/pdf' })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `reporte-${reportConfig.tipo}-${new Date().toISOString().split('T')[0]}.${reportConfig.formato}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

    } catch (error) {
      toast({
        title: "Error al generar reporte",
        description: "Por favor intenta nuevamente",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <Card className="seguros-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="h-5 w-5 mr-2 text-[#2E7D32]" />
          Generador de Reportes
        </CardTitle>
        <CardDescription>
          Genera reportes personalizados con filtros avanzados
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Tipo de Reporte *</Label>
            <Select value={reportConfig.tipo} onValueChange={(value) => setReportConfig(prev => ({ ...prev, tipo: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona el tipo de reporte" />
              </SelectTrigger>
              <SelectContent>
                {tiposReporte.map(tipo => {
                  const Icon = tipo.icon
                  return (
                    <SelectItem key={tipo.value} value={tipo.value}>
                      <div className="flex items-center">
                        <Icon className="h-4 w-4 mr-2" />
                        {tipo.label}
                      </div>
                    </SelectItem>
                  )
                })}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Formato</Label>
            <Select value={reportConfig.formato} onValueChange={(value) => setReportConfig(prev => ({ ...prev, formato: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pdf">PDF</SelectItem>
                <SelectItem value="excel">Excel</SelectItem>
                <SelectItem value="csv">CSV</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Fecha de Inicio</Label>
            <Input
              type="date"
              value={reportConfig.fechaInicio}
              onChange={(e) => setReportConfig(prev => ({ ...prev, fechaInicio: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label>Fecha de Fin</Label>
            <Input
              type="date"
              value={reportConfig.fechaFin}
              onChange={(e) => setReportConfig(prev => ({ ...prev, fechaFin: e.target.value }))}
            />
          </div>
        </div>

        {user?.role === 'admin' && (
          <div className="space-y-2">
            <Label>Empresa (Opcional)</Label>
            <Select value={reportConfig.empresaId} onValueChange={(value) => setReportConfig(prev => ({ ...prev, empresaId: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Todas las empresas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todas las empresas</SelectItem>
                {empresasFiltradas.map(empresa => (
                  <SelectItem key={empresa.id} value={empresa.id}>
                    {empresa.nombre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {(user?.role === 'admin' || user?.role === 'empresa') && (
          <div className="space-y-2">
            <Label>Profesional (Opcional)</Label>
            <Select value={reportConfig.profesionalId} onValueChange={(value) => setReportConfig(prev => ({ ...prev, profesionalId: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Todos los profesionales" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todos los profesionales</SelectItem>
                {profesionalesFiltrados.map(profesional => (
                  <SelectItem key={profesional.id} value={profesional.id}>
                    {profesional.nombre} - {profesional.especialidad}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-3">
          <Label>Opciones del Reporte</Label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="incluirDetalles"
                checked={reportConfig.incluirDetalles}
                onCheckedChange={(checked) => setReportConfig(prev => ({ ...prev, incluirDetalles: !!checked }))}
              />
              <Label htmlFor="incluirDetalles" className="text-sm">
                Incluir detalles completos
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="incluirGraficas"
                checked={reportConfig.incluirGraficas}
                onCheckedChange={(checked) => setReportConfig(prev => ({ ...prev, incluirGraficas: !!checked }))}
              />
              <Label htmlFor="incluirGraficas" className="text-sm">
                Incluir gráficas y estadísticas
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="incluirResumen"
                checked={reportConfig.incluirResumen}
                onCheckedChange={(checked) => setReportConfig(prev => ({ ...prev, incluirResumen: !!checked }))}
              />
              <Label htmlFor="incluirResumen" className="text-sm">
                Incluir resumen ejecutivo
              </Label>
            </div>
          </div>
        </div>

        <Button 
          onClick={handleGenerate} 
          className="w-full seguros-button-primary"
          disabled={isGenerating}
        >
          {isGenerating ? (
            'Generando reporte...'
          ) : (
            <>
              <Download className="h-4 w-4 mr-2" />
              Generar y Descargar Reporte
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
