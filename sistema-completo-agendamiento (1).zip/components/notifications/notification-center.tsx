'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Bell, Check, X, Info, AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react'
import { mockNotificaciones, type Notificacion } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'
import { formatDateTime } from '@/lib/utils/date-utils'
import { cn } from '@/lib/utils'

export function NotificationCenter() {
  const { user } = useAuth()
  const [notifications, setNotifications] = useState(
    mockNotificaciones.filter(n => n.destinatarioId === user?.id && n.destinatarioTipo === user?.role)
  )

  const unreadCount = notifications.filter(n => !n.leida).length

  const getIcon = (tipo: Notificacion['tipo']) => {
    switch (tipo) {
      case 'info':
        return <Info className="h-4 w-4 text-blue-500" />
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Bell className="h-4 w-4 text-gray-500" />
    }
  }

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, leida: true } : n)
    )
  }

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, leida: true }))
    )
  }

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  return (
    <Card className="seguros-card">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <CardTitle className="flex items-center">
              <Bell className="h-5 w-5 mr-2 text-[#2E7D32]" />
              Notificaciones
            </CardTitle>
            {unreadCount > 0 && (
              <Badge className="bg-[#FBC02D] text-gray-900">
                {unreadCount}
              </Badge>
            )}
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              <Check className="h-4 w-4 mr-2" />
              Marcar todas como leídas
            </Button>
          )}
        </div>
        <CardDescription>
          Centro de notificaciones y alertas del sistema
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No tienes notificaciones</p>
              </div>
            ) : (
              notifications.map(notification => (
                <div
                  key={notification.id}
                  className={cn(
                    "flex items-start space-x-3 p-3 rounded-lg border transition-colors",
                    notification.leida 
                      ? "bg-gray-50 border-gray-200" 
                      : "bg-white border-[#2E7D32] border-opacity-20 shadow-sm"
                  )}
                >
                  <div className="flex-shrink-0 mt-1">
                    {getIcon(notification.tipo)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h4 className={cn(
                        "text-sm font-medium",
                        !notification.leida && "text-gray-900"
                      )}>
                        {notification.titulo}
                      </h4>
                      <div className="flex items-center space-x-1 ml-2">
                        {!notification.leida && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                            className="h-6 w-6 p-0"
                          >
                            <Check className="h-3 w-3" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteNotification(notification.id)}
                          className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mt-1">
                      {notification.mensaje}
                    </p>
                    
                    <p className="text-xs text-gray-500 mt-2">
                      {formatDateTime(notification.createdAt)}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
