'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/providers/auth-provider'
import { Clock, Ban, Sparkles } from 'lucide-react'

interface BloqueoHorarioFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
  fechaSeleccionada?: string
  horaSeleccionada?: string
}

export function BloqueoHorarioForm({ 
  open, 
  onOpenChange, 
  onSuccess, 
  fechaSeleccionada = '',
  horaSeleccionada = ''
}: BloqueoHorarioFormProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    fecha: fechaSeleccionada,
    horaInicio: horaSeleccionada,
    horaFin: '',
    tipoBloqueo: 'personal',
    motivo: '',
    descripcion: ''
  })

  const tiposBloqueo = [
    { value: 'personal', label: '🧑‍💼 Tiempo Personal', color: 'bg-red-100 text-red-800' },
    { value: 'almuerzo', label: '🍽️ Almuerzo', color: 'bg-orange-100 text-orange-800' },
    { value: 'reunion', label: '👥 Reunión', color: 'bg-purple-100 text-purple-800' },
    { value: 'capacitacion', label: '📚 Capacitación', color: 'bg-green-100 text-green-800' },
    { value: 'emergencia', label: '🚨 Emergencia', color: 'bg-red-100 text-red-800' },
    { value: 'mantenimiento', label: '🔧 Mantenimiento', color: 'bg-gray-100 text-gray-800' },
    { value: 'otro', label: '📋 Otro', color: 'bg-yellow-100 text-yellow-800' }
  ]

  const calcularDuracion = () => {
    if (formData.horaInicio && formData.horaFin) {
      const inicio = new Date(`2000-01-01T${formData.horaInicio}:00`)
      const fin = new Date(`2000-01-01T${formData.horaFin}:00`)
      const diff = (fin.getTime() - inicio.getTime()) / (1000 * 60)
      return diff > 0 ? diff : 0
    }
    return 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const duracion = calcularDuracion()
      if (duracion <= 0) {
        throw new Error('La hora de fin debe ser posterior a la hora de inicio')
      }

      // Simular guardado del bloqueo
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast({
        title: "🎉 Horario bloqueado exitosamente",
        description: `Se bloqueó el horario de ${formData.horaInicio} a ${formData.horaFin} el ${formData.fecha}`,
      })
      
      onOpenChange(false)
      onSuccess?.()
      
      // Reset form
      setFormData({
        fecha: '',
        horaInicio: '',
        horaFin: '',
        tipoBloqueo: 'personal',
        motivo: '',
        descripcion: ''
      })
    } catch (error) {
      toast({
        title: "❌ Error al bloquear horario",
        description: error instanceof Error ? error.message : "Por favor intenta nuevamente",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] seguros-card">
        <DialogHeader className="bg-gradient-to-r from-red-50 to-orange-50 -m-6 p-6 mb-4 rounded-t-xl border-b border-red-100">
          <DialogTitle className="flex items-center text-xl">
            <Ban className="h-6 w-6 mr-3 text-red-600" />
            🚫 Bloquear Horario
          </DialogTitle>
          <DialogDescription className="text-gray-700">
            Bloquea un horario específico para evitar que se agenden citas en ese período.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fecha" className="font-semibold text-gray-700">📅 Fecha *</Label>
              <Input
                id="fecha"
                type="date"
                value={formData.fecha}
                onChange={(e) => setFormData(prev => ({ ...prev, fecha: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
                className="seguros-input shadow-sm"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="tipoBloqueo" className="font-semibold text-gray-700">🏷️ Tipo de Bloqueo *</Label>
              <Select value={formData.tipoBloqueo} onValueChange={(value) => setFormData(prev => ({ ...prev, tipoBloqueo: value }))}>
                <SelectTrigger className="seguros-select shadow-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tiposBloqueo.map(tipo => (
                    <SelectItem key={tipo.value} value={tipo.value}>
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${tipo.color.split(' ')[0]}`}></div>
                        <span>{tipo.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="horaInicio" className="font-semibold text-gray-700">🕐 Hora de Inicio *</Label>
              <Input
                id="horaInicio"
                type="time"
                value={formData.horaInicio}
                onChange={(e) => setFormData(prev => ({ ...prev, horaInicio: e.target.value }))}
                className="seguros-input shadow-sm"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="horaFin" className="font-semibold text-gray-700">🕐 Hora de Fin *</Label>
              <Input
                id="horaFin"
                type="time"
                value={formData.horaFin}
                onChange={(e) => setFormData(prev => ({ ...prev, horaFin: e.target.value }))}
                className="seguros-input shadow-sm"
                required
              />
            </div>
          </div>

          {formData.horaInicio && formData.horaFin && (
            <div className="p-4 bg-gradient-to-r from-green-50 to-yellow-50 rounded-xl border-2 border-green-200 shadow-sm">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-green-600" />
                <Sparkles className="h-4 w-4 text-yellow-600" />
                <p className="text-sm font-bold text-green-800">
                  ⏱️ Duración del bloqueo: {calcularDuracion()} minutos
                </p>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="motivo" className="font-semibold text-gray-700">📝 Motivo del Bloqueo *</Label>
            <Input
              id="motivo"
              value={formData.motivo}
              onChange={(e) => setFormData(prev => ({ ...prev, motivo: e.target.value }))}
              placeholder="Ej: Reunión de equipo, Almuerzo, Capacitación..."
              className="seguros-input shadow-sm"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descripcion" className="font-semibold text-gray-700">📄 Descripción adicional</Label>
            <Textarea
              id="descripcion"
              value={formData.descripcion}
              onChange={(e) => setFormData(prev => ({ ...prev, descripcion: e.target.value }))}
              placeholder="Información adicional sobre el bloqueo..."
              rows={3}
              className="seguros-input shadow-sm"
            />
          </div>

          <DialogFooter className="pt-4 border-t border-gray-100">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="font-semibold">
              Cancelar
            </Button>
            <Button type="submit" className="seguros-button-primary" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Sparkles className="h-4 w-4 mr-2 animate-spin" />
                  Bloqueando...
                </>
              ) : (
                <>
                  <Ban className="h-4 w-4 mr-2" />
                  Bloquear Horario
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
