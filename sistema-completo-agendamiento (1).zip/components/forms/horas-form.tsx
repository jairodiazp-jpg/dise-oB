'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/providers/auth-provider'

interface HorasFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function HorasForm({ open, onOpenChange, onSuccess }: HorasFormProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    fecha: '',
    horaInicio: '',
    horaFin: '',
    descripcion: ''
  })

  const calcularHoras = () => {
    if (formData.horaInicio && formData.horaFin) {
      const inicio = new Date(`2000-01-01T${formData.horaInicio}:00`)
      const fin = new Date(`2000-01-01T${formData.horaFin}:00`)
      const diff = (fin.getTime() - inicio.getTime()) / (1000 * 60 * 60)
      return diff > 0 ? diff : 0
    }
    return 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const totalHoras = calcularHoras()
      if (totalHoras <= 0) {
        throw new Error('La hora de fin debe ser posterior a la hora de inicio')
      }

      // Simular guardado
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast({
        title: "Horas registradas exitosamente",
        description: `Se registraron ${totalHoras} horas para el ${formData.fecha}`,
      })
      
      onOpenChange(false)
      onSuccess?.()
      
      // Reset form
      setFormData({
        fecha: '',
        horaInicio: '',
        horaFin: '',
        descripcion: ''
      })
    } catch (error) {
      toast({
        title: "Error al registrar horas",
        description: error instanceof Error ? error.message : "Por favor intenta nuevamente",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>Registrar Horas Trabajadas</DialogTitle>
          <DialogDescription>
            Registra las horas trabajadas para el día seleccionado.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fecha">Fecha *</Label>
            <Input
              id="fecha"
              type="date"
              value={formData.fecha}
              onChange={(e) => setFormData(prev => ({ ...prev, fecha: e.target.value }))}
              max={new Date().toISOString().split('T')[0]}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="horaInicio">Hora de Inicio *</Label>
              <Input
                id="horaInicio"
                type="time"
                value={formData.horaInicio}
                onChange={(e) => setFormData(prev => ({ ...prev, horaInicio: e.target.value }))}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="horaFin">Hora de Fin *</Label>
              <Input
                id="horaFin"
                type="time"
                value={formData.horaFin}
                onChange={(e) => setFormData(prev => ({ ...prev, horaFin: e.target.value }))}
                required
              />
            </div>
          </div>

          {formData.horaInicio && formData.horaFin && (
            <div className="p-3 bg-[#2E7D32] bg-opacity-10 rounded-lg">
              <p className="text-sm font-medium text-[#2E7D32]">
                Total de horas: {calcularHoras().toFixed(1)} horas
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="descripcion">Descripción de actividades</Label>
            <Textarea
              id="descripcion"
              value={formData.descripcion}
              onChange={(e) => setFormData(prev => ({ ...prev, descripcion: e.target.value }))}
              placeholder="Describe las actividades realizadas durante estas horas..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" className="seguros-button-primary" disabled={isLoading}>
              {isLoading ? 'Registrando...' : 'Registrar Horas'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
