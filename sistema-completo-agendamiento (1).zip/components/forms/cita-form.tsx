'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { mockProfesionales, mockEmpresas } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'

interface CitaFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function CitaForm({ open, onOpenChange, onSuccess }: CitaFormProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    pacienteNombre: '',
    pacienteTelefono: '',
    pacienteEmail: '',
    profesionalId: user?.role === 'profesional' ? user.id : '',
    fecha: '',
    hora: '',
    duracion: '30',
    tipo: '',
    notas: ''
  })

  const profesionalesFiltrados = user?.role === 'empresa' 
    ? mockProfesionales.filter(p => p.empresaId === user.empresaId)
    : mockProfesionales

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simular guardado
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast({
        title: "Cita agendada exitosamente",
        description: `Cita para ${formData.pacienteNombre} el ${formData.fecha} a las ${formData.hora}`,
      })
      
      onOpenChange(false)
      onSuccess?.()
      
      // Reset form
      setFormData({
        pacienteNombre: '',
        pacienteTelefono: '',
        pacienteEmail: '',
        profesionalId: user?.role === 'profesional' ? user.id : '',
        fecha: '',
        hora: '',
        duracion: '30',
        tipo: '',
        notas: ''
      })
    } catch (error) {
      toast({
        title: "Error al agendar cita",
        description: "Por favor intenta nuevamente",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Agendar Nueva Cita</DialogTitle>
          <DialogDescription>
            Completa la información para agendar una nueva cita médica.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="pacienteNombre">Nombre del Paciente *</Label>
              <Input
                id="pacienteNombre"
                value={formData.pacienteNombre}
                onChange={(e) => setFormData(prev => ({ ...prev, pacienteNombre: e.target.value }))}
                placeholder="Nombre completo"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="pacienteTelefono">Teléfono *</Label>
              <Input
                id="pacienteTelefono"
                value={formData.pacienteTelefono}
                onChange={(e) => setFormData(prev => ({ ...prev, pacienteTelefono: e.target.value }))}
                placeholder="+57 300 123-4567"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="pacienteEmail">Email</Label>
            <Input
              id="pacienteEmail"
              type="email"
              value={formData.pacienteEmail}
              onChange={(e) => setFormData(prev => ({ ...prev, pacienteEmail: e.target.value }))}
              placeholder="paciente@email.com"
            />
          </div>

          {user?.role !== 'profesional' && (
            <div className="space-y-2">
              <Label htmlFor="profesionalId">Profesional *</Label>
              <Select value={formData.profesionalId} onValueChange={(value) => setFormData(prev => ({ ...prev, profesionalId: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un profesional" />
                </SelectTrigger>
                <SelectContent>
                  {profesionalesFiltrados.map(profesional => (
                    <SelectItem key={profesional.id} value={profesional.id}>
                      {profesional.nombre} - {profesional.especialidad}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fecha">Fecha *</Label>
              <Input
                id="fecha"
                type="date"
                value={formData.fecha}
                onChange={(e) => setFormData(prev => ({ ...prev, fecha: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="hora">Hora *</Label>
              <Input
                id="hora"
                type="time"
                value={formData.hora}
                onChange={(e) => setFormData(prev => ({ ...prev, hora: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duracion">Duración (minutos) *</Label>
              <Select value={formData.duracion} onValueChange={(value) => setFormData(prev => ({ ...prev, duracion: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutos</SelectItem>
                  <SelectItem value="30">30 minutos</SelectItem>
                  <SelectItem value="45">45 minutos</SelectItem>
                  <SelectItem value="60">1 hora</SelectItem>
                  <SelectItem value="90">1.5 horas</SelectItem>
                  <SelectItem value="120">2 horas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="tipo">Tipo de Cita *</Label>
              <Select value={formData.tipo} onValueChange={(value) => setFormData(prev => ({ ...prev, tipo: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Consulta General">Consulta General</SelectItem>
                  <SelectItem value="Control">Control</SelectItem>
                  <SelectItem value="Seguimiento">Seguimiento</SelectItem>
                  <SelectItem value="Procedimiento">Procedimiento</SelectItem>
                  <SelectItem value="Urgencia">Urgencia</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notas">Notas adicionales</Label>
            <Textarea
              id="notas"
              value={formData.notas}
              onChange={(e) => setFormData(prev => ({ ...prev, notas: e.target.value }))}
              placeholder="Información adicional sobre la cita..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-green-700 hover:bg-green-800 text-white" disabled={isLoading}>
              {isLoading ? 'Agendando...' : 'Agendar Cita'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
