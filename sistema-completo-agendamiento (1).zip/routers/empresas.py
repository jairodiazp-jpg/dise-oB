from fastapi import APIRouter

router = APIRouter(prefix="/empresas", tags=["Empresas"])

@router.get("/")
async def listar_empresas():
    return [{"id": 1, "nombre": "Clínica Vida"}]
