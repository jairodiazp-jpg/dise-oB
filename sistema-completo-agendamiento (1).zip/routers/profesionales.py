from fastapi import APIRouter

router = APIRouter(prefix="/profesionales", tags=["Profesionales"])

@router.get("/")
async def listar_profesionales():
    return [{"id": 1, "nombre": "Dra. Ana María"}]
