from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/citas", tags=["Citas"])

citas_db = []

class Cita(BaseModel):
    nombre_paciente: str
    nombre_profesional: str
    especialidad: str
    fecha: str
    hora: str

@router.get("/")
async def listar_citas():
    return citas_db

@router.post("/")
async def crear_cita(cita: Cita):
    citas_db.append(cita.dict())
    return {"message": "Cita agendada correctamente"}
