'use client'

import { NotificationCenter } from '@/components/notifications/notification-center'

export default function NotificacionesAdmin() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Centro de Notificaciones</h1>
        <p className="text-gray-600 mt-2">Gestiona notificaciones del sistema</p>
      </div>

      <NotificationCenter />
    </div>
  )
}
