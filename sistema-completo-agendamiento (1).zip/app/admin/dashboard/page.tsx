'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Building2, Users, Calendar, Clock, TrendingUp, Activity, AlertCircle, CheckCircle, Plus, FileText } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { CitaForm } from '@/components/forms/cita-form'
import { HorasForm } from '@/components/forms/horas-form'
import { ReportGenerator } from '@/components/reports/report-generator'

const citasData = [
  { mes: 'Ene', citas: 120, realizadas: 115 },
  { mes: 'Feb', citas: 135, realizadas: 128 },
  { mes: 'Mar', citas: 148, realizadas: 142 },
  { mes: 'Abr', citas: 162, realizadas: 158 },
  { mes: 'May', citas: 178, realizadas: 171 },
  { mes: 'Jun', citas: 195, realizadas: 189 },
]

const empresasData = [
  { name: 'Clínica Vida', value: 45, color: '#2E7D32' },
  { name: 'Centro Médico Salud', value: 35, color: '#FBC02D' },
  { name: 'Hospital San José', value: 20, color: '#1976D2' },
]

export default function AdminDashboard() {
  const [showCitaForm, setShowCitaForm] = useState(false)
  const [showHorasForm, setShowHorasForm] = useState(false)
  const [showReportGenerator, setShowReportGenerator] = useState(false)

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Administrativo</h1>
          <p className="text-gray-600 mt-2">Vista general del sistema de agendamiento</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => setShowCitaForm(true)} className="bg-green-700 hover:bg-green-800 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Nueva Cita
          </Button>
          <Button onClick={() => setShowHorasForm(true)} variant="outline">
            <Clock className="h-4 w-4 mr-2" />
            Registrar Horas
          </Button>
          <Button onClick={() => setShowReportGenerator(true)} variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Generar Reporte
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Empresas</CardTitle>
            <Building2 className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+1</span> desde el mes pasado
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profesionales Activos</CardTitle>
            <Users className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">247</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12</span> nuevos este mes
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Citas Este Mes</CardTitle>
            <Calendar className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+8.2%</span> vs mes anterior
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Horas Trabajadas</CardTitle>
            <Clock className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8,456</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+5.1%</span> este mes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Citas Chart */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Citas Agendadas vs Realizadas</CardTitle>
            <CardDescription>Comparación mensual de citas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={citasData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="citas" fill="#2E7D32" name="Agendadas" />
                <Bar dataKey="realizadas" fill="#FBC02D" name="Realizadas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Empresas Distribution */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Distribución por Empresa</CardTitle>
            <CardDescription>Porcentaje de citas por empresa</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={empresasData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {empresasData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Activity and Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2 text-green-700" />
              Actividad Reciente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Nueva cita agendada</p>
                <p className="text-xs text-gray-500">Dr. Carlos - Cardiología - hace 5 min</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Profesional registrado</p>
                <p className="text-xs text-gray-500">Dra. María González - hace 15 min</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Horas trabajadas cargadas</p>
                <p className="text-xs text-gray-500">Clínica Vida - 40 horas - hace 1 hora</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-700" />
              Estado del Sistema
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Servicios Activos</span>
              </div>
              <Badge className="bg-green-100 text-green-800">100%</Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Uso de Base de Datos</span>
                <span>67%</span>
              </div>
              <Progress value={67} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Usuarios Conectados</span>
                <span>89%</span>
              </div>
              <Progress value={89} className="h-2" />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-4 w-4 text-yellow-500" />
                <span className="text-sm">Alertas Pendientes</span>
              </div>
              <Badge className="bg-yellow-100 text-yellow-800">2</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <CitaForm
        open={showCitaForm}
        onOpenChange={setShowCitaForm}
        onSuccess={() => {
          console.log('Cita creada exitosamente')
        }}
      />

      <HorasForm
        open={showHorasForm}
        onOpenChange={setShowHorasForm}
        onSuccess={() => {
          console.log('Horas registradas exitosamente')
        }}
      />

      {showReportGenerator && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Generar Reporte</h2>
              <Button variant="ghost" onClick={() => setShowReportGenerator(false)}>
                ✕
              </Button>
            </div>
            <ReportGenerator />
          </div>
        </div>
      )}
    </div>
  )
}
