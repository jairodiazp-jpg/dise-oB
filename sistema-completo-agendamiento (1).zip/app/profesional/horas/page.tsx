'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, Clock, Calendar, TrendingUp } from 'lucide-react'
import { HorasForm } from '@/components/forms/horas-form'
import { mockHorasTrabajadas } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'
import { formatDate } from '@/lib/utils/date-utils'

export default function HorasProfesional() {
  const { user } = useAuth()
  const [showHorasForm, setShowHorasForm] = useState(false)

  const horasDelProfesional = mockHorasTrabajadas.filter(h => h.profesionalId === user?.id)
  const totalHorasEsteMes = horasDelProfesional.reduce((total, hora) => total + hora.totalHoras, 0)
  const promedioHorasDiarias = totalHorasEsteMes / 30

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mis Horas Trabajadas</h1>
          <p className="text-gray-600 mt-2">Registra y gestiona tus horas de trabajo</p>
        </div>
        <Button onClick={() => setShowHorasForm(true)} className="seguros-button-primary">
          <Plus className="h-4 w-4 mr-2" />
          Registrar Horas
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Horas Este Mes</CardTitle>
            <Clock className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalHorasEsteMes}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+5.2%</span> vs mes anterior
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Promedio Diario</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{promedioHorasDiarias.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">
              Horas por día
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Días Registrados</CardTitle>
            <Calendar className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{horasDelProfesional.length}</div>
            <p className="text-xs text-muted-foreground">
              Este mes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Historial de Horas */}
      <Card className="seguros-card">
        <CardHeader>
          <CardTitle>Historial de Horas Trabajadas</CardTitle>
          <CardDescription>Registro detallado de tus horas de trabajo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {horasDelProfesional.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No has registrado horas trabajadas aún</p>
                <Button 
                  onClick={() => setShowHorasForm(true)} 
                  className="mt-4 seguros-button-primary"
                >
                  Registrar Primeras Horas
                </Button>
              </div>
            ) : (
              horasDelProfesional.map(hora => (
                <div key={hora.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-[#2E7D32] rounded-full flex items-center justify-center">
                      <Clock className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">
                        {formatDate(hora.fecha)}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {hora.horaInicio} - {hora.horaFin}
                      </p>
                      {hora.descripcion && (
                        <p className="text-sm text-gray-500 mt-1">
                          {hora.descripcion}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-[#2E7D32] text-white">
                      {hora.totalHoras} horas
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(hora.createdAt).toLocaleDateString('es-ES')}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <HorasForm
        open={showHorasForm}
        onOpenChange={setShowHorasForm}
        onSuccess={() => {
          console.log('Horas registradas exitosamente')
        }}
      />
    </div>
  )
}
