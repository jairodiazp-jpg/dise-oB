'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Calendar, Plus, Ban, Clock, User, BarChart3, Edit, Trash2 } from 'lucide-react'
import { InteractiveCalendar } from '@/components/calendar/interactive-calendar'
import { CitaForm } from '@/components/forms/cita-form'
import { BloqueoHorarioForm } from '@/components/forms/bloqueo-horario-form'
import { IntelligentDashboard } from '@/components/dashboard/intelligent-dashboard'
import { useAuth } from '@/components/providers/auth-provider'
import { mockCitas, type Cita } from '@/lib/data/mock-data'
import { useToast } from '@/hooks/use-toast'

export default function AgendaProfesional() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [showCitaForm, setShowCitaForm] = useState(false)
  const [showBloqueoForm, setShowBloqueoForm] = useState(false)
  const [showDashboard, setShowDashboard] = useState(false)
  const [editingCita, setEditingCita] = useState<Cita | null>(null)
  const [fechaSeleccionada, setFechaSeleccionada] = useState('')
  const [horaSeleccionada, setHoraSeleccionada] = useState('')

  const handleNewCita = (fecha?: string, hora?: string) => {
    setFechaSeleccionada(fecha || '')
    setHoraSeleccionada(hora || '')
    setEditingCita(null)
    setShowCitaForm(true)
  }

  const handleEditCita = (cita: Cita) => {
    setEditingCita(cita)
    setShowCitaForm(true)
  }

  const handleDeleteCita = (citaId: string) => {
    // Simular eliminación
    toast({
      title: "🗑️ Cita eliminada",
      description: "La cita ha sido eliminada exitosamente",
    })
  }

  const handleBloquearHorario = (fecha?: string, hora?: string) => {
    setFechaSeleccionada(fecha || '')
    setHoraSeleccionada(hora || '')
    setShowBloqueoForm(true)
  }

  const estadisticasDelDia = {
    citasHoy: 4,
    citasConfirmadas: 3,
    citasPendientes: 1,
    horasLibres: 6,
    horasBloqueadas: 2
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header mejorado */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-green-600 bg-clip-text text-transparent">
            📅 Mi Agenda Profesional
          </h1>
          <p className="text-gray-600 mt-2 flex items-center space-x-2">
            <span>Gestiona tus citas, horarios y bloqueos</span>
            <Badge className="bg-green-100 text-green-800 border-green-300">
              {user?.especialidad}
            </Badge>
            <Badge variant="outline" className="border-green-300">
              {user?.empresaNombre}
            </Badge>
          </p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => setShowDashboard(!showDashboard)} variant="outline" className="border-green-200 hover:bg-green-50">
            <BarChart3 className="h-4 w-4 mr-2" />
            {showDashboard ? 'Ocultar' : 'Ver'} Dashboard
          </Button>
          <Button onClick={() => handleNewCita()} className="seguros-button-primary">
            <Plus className="h-4 w-4 mr-2" />
            Nueva Cita
          </Button>
          <Button onClick={() => handleBloquearHorario()} variant="outline" className="border-red-200 text-red-600 hover:bg-red-50">
            <Ban className="h-4 w-4 mr-2" />
            Bloquear Horario
          </Button>
        </div>
      </div>

      {/* Dashboard inteligente (condicional) */}
      {showDashboard && (
        <IntelligentDashboard 
          profesionalId={user?.id}
          realTimeUpdates={true}
        />
      )}

      {/* Estadísticas rápidas mejoradas */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="seguros-card bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Calendar className="h-6 w-6 text-green-600" />
              <div>
                <p className="text-2xl font-bold text-green-700">{estadisticasDelDia.citasHoy}</p>
                <p className="text-xs text-green-600 font-medium">📅 Citas Hoy</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">✓</span>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-700">{estadisticasDelDia.citasConfirmadas}</p>
                <p className="text-xs text-green-600 font-medium">✅ Confirmadas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">⏳</span>
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-700">{estadisticasDelDia.citasPendientes}</p>
                <p className="text-xs text-yellow-600 font-medium">⏳ Pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Clock className="h-6 w-6 text-gray-600" />
              <div>
                <p className="text-2xl font-bold text-gray-700">{estadisticasDelDia.horasLibres}</p>
                <p className="text-xs text-gray-600 font-medium">🕐 Horas Libres</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="seguros-card bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Ban className="h-6 w-6 text-red-600" />
              <div>
                <p className="text-2xl font-bold text-red-700">{estadisticasDelDia.horasBloqueadas}</p>
                <p className="text-xs text-red-600 font-medium">🚫 Bloqueadas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leyenda mejorada */}
      <Card className="seguros-card bg-gradient-to-r from-green-50 to-yellow-50 border-green-200">
        <CardContent className="p-4">
          <h3 className="font-semibold text-green-800 mb-3 flex items-center">
            🎨 Leyenda del Calendario
          </h3>
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 rounded"></div>
              <span className="text-sm text-gray-700 font-medium">📋 Citas Médicas</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-100 border-2 border-red-200 rounded"></div>
              <span className="text-sm text-gray-700 font-medium">🚫 Horarios Bloqueados</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-gradient-to-r from-green-50 to-yellow-50 border-2 border-green-200 rounded"></div>
              <span className="text-sm text-gray-700 font-medium">⏱️ Horas Trabajadas</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-gray-50 border-2 border-dashed border-gray-300 rounded"></div>
              <span className="text-sm text-gray-700 font-medium">✨ Horarios Disponibles</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Calendario interactivo principal */}
      <InteractiveCalendar 
        profesionalId={user?.id}
        onNewCita={handleNewCita}
        onEditCita={handleEditCita}
        onDeleteCita={handleDeleteCita}
        realTimeUpdates={true}
      />

      {/* Modals */}
      <CitaForm
        open={showCitaForm}
        onOpenChange={setShowCitaForm}
        editingCita={editingCita}
        fechaSeleccionada={fechaSeleccionada}
        horaSeleccionada={horaSeleccionada}
        onSuccess={() => {
          toast({
            title: editingCita ? "✏️ Cita actualizada" : "🎉 Cita creada",
            description: editingCita ? "La cita ha sido actualizada exitosamente" : "Nueva cita agendada exitosamente",
          })
        }}
      />

      <BloqueoHorarioForm
        open={showBloqueoForm}
        onOpenChange={setShowBloqueoForm}
        fechaSeleccionada={fechaSeleccionada}
        horaSeleccionada={horaSeleccionada}
        onSuccess={() => {
          toast({
            title: "🚫 Horario bloqueado",
            description: "El horario ha sido bloqueado exitosamente",
          })
        }}
      />
    </div>
  )
}
