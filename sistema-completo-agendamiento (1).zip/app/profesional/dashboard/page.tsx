'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Calendar, Clock, Users, CheckCircle, AlertCircle, Plus, CalendarDays, Timer } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { CitaForm } from '@/components/forms/cita-form'
import { HorasForm } from '@/components/forms/horas-form'

export default function ProfesionalDashboard() {
  const { user } = useAuth()
  const [showCitaForm, setShowCitaForm] = useState(false)
  const [showHorasForm, setShowHorasForm] = useState(false)

  const citasHoy = [
    { id: 1, paciente: 'María González', hora: '09:00', tipo: 'Consulta', estado: 'confirmada' },
    { id: 2, paciente: 'Carlos Ruiz', hora: '10:30', tipo: 'Control', estado: 'pendiente' },
    { id: 3, paciente: 'Ana Martínez', hora: '14:00', tipo: 'Consulta', estado: 'confirmada' },
    { id: 4, paciente: 'Luis Pérez', hora: '15:30', tipo: 'Seguimiento', estado: 'confirmada' },
  ]

  const proximasCitas = [
    { fecha: 'Mañana', paciente: 'Roberto Silva', hora: '08:30' },
    { fecha: 'Miércoles', paciente: 'Carmen López', hora: '11:00' },
    { fecha: 'Jueves', paciente: 'Diego Morales', hora: '16:00' },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bienvenido, {user?.name?.split(' ')[1] || user?.name}
          </h1>
          <p className="text-gray-600 mt-2">
            {user?.especialidad} • {user?.empresaNombre} • Hoy es {new Date().toLocaleDateString('es-ES', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => setShowCitaForm(true)} className="bg-green-700 hover:bg-green-800 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Nueva Cita
          </Button>
          <Button onClick={() => setShowHorasForm(true)} variant="outline">
            <Timer className="h-4 w-4 mr-2" />
            Cargar Horas
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Citas Hoy</CardTitle>
            <Calendar className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">3</span> confirmadas
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Esta Semana</CardTitle>
            <CalendarDays className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+2</span> vs semana anterior
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Horas Trabajadas</CardTitle>
            <Clock className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32</div>
            <p className="text-xs text-muted-foreground">
              Esta semana
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pacientes Atendidos</CardTitle>
            <Users className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-muted-foreground">
              Este mes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Citas de Hoy */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-700" />
              Citas de Hoy
            </CardTitle>
            <CardDescription>
              {new Date().toLocaleDateString('es-ES', { 
                weekday: 'long', 
                day: 'numeric', 
                month: 'long' 
              })}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {citasHoy.map((cita) => (
              <div key={cita.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="text-sm font-medium text-green-700">
                    {cita.hora}
                  </div>
                  <div>
                    <p className="font-medium">{cita.paciente}</p>
                    <p className="text-sm text-gray-500">{cita.tipo}</p>
                  </div>
                </div>
                <Badge 
                  variant={cita.estado === 'confirmada' ? 'default' : 'secondary'}
                  className={cita.estado === 'confirmada' ? 'bg-green-100 text-green-800' : ''}
                >
                  {cita.estado === 'confirmada' ? (
                    <CheckCircle className="h-3 w-3 mr-1" />
                  ) : (
                    <AlertCircle className="h-3 w-3 mr-1" />
                  )}
                  {cita.estado}
                </Badge>
              </div>
            ))}
            
            {citasHoy.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No tienes citas programadas para hoy</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Próximas Citas */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CalendarDays className="h-5 w-5 mr-2 text-green-700" />
              Próximas Citas
            </CardTitle>
            <CardDescription>Agenda de los próximos días</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {proximasCitas.map((cita, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="text-sm font-medium text-green-700">
                    {cita.fecha}
                  </div>
                  <div>
                    <p className="font-medium">{cita.paciente}</p>
                    <p className="text-sm text-gray-500">{cita.hora}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  Ver detalles
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
          <CardDescription>Gestiona tu agenda y actividades</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => window.location.href = '/profesional/agenda'}
            >
              <Calendar className="h-6 w-6 text-green-700" />
              <span>Ver Agenda Completa</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => setShowHorasForm(true)}
            >
              <Clock className="h-6 w-6 text-green-700" />
              <span>Cargar Horas Trabajadas</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => setShowCitaForm(true)}
            >
              <Users className="h-6 w-6 text-green-700" />
              <span>Agendar Nueva Cita</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <CitaForm
        open={showCitaForm}
        onOpenChange={setShowCitaForm}
        onSuccess={() => {
          console.log('Cita creada exitosamente')
        }}
      />

      <HorasForm
        open={showHorasForm}
        onOpenChange={setShowHorasForm}
        onSuccess={() => {
          console.log('Horas registradas exitosamente')
        }}
      />
    </div>
  )
}
