'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Users, Calendar, Clock, TrendingUp, Plus, UserCheck, CalendarCheck, AlertTriangle, FileText } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import { CitaForm } from '@/components/forms/cita-form'
import { HorasForm } from '@/components/forms/horas-form'
import { ReportGenerator } from '@/components/reports/report-generator'
import { useAuth } from '@/components/providers/auth-provider'

const citasSemanales = [
  { dia: 'Lun', citas: 12, realizadas: 11 },
  { dia: 'Mar', citas: 15, realizadas: 14 },
  { dia: 'Mié', citas: 18, realizadas: 17 },
  { dia: 'Jue', citas: 14, realizadas: 13 },
  { dia: 'Vie', citas: 20, realizadas: 19 },
  { dia: 'Sáb', citas: 8, realizadas: 8 },
  { dia: 'Dom', citas: 5, realizadas: 5 },
]

const horasData = [
  { semana: 'S1', horas: 320 },
  { semana: 'S2', horas: 285 },
  { semana: 'S3', horas: 340 },
  { semana: 'S4', horas: 298 },
]

export default function EmpresaDashboard() {
  const { user } = useAuth()
  const [showCitaForm, setShowCitaForm] = useState(false)
  const [showHorasForm, setShowHorasForm] = useState(false)
  const [showReportGenerator, setShowReportGenerator] = useState(false)

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Empresarial</h1>
          <p className="text-gray-600 mt-2">Gestión de {user?.empresaNombre || 'tu centro médico'}</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => setShowCitaForm(true)} className="bg-green-700 hover:bg-green-800 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Nueva Cita
          </Button>
          <Button onClick={() => setShowHorasForm(true)} variant="outline">
            <Clock className="h-4 w-4 mr-2" />
            Registrar Horas
          </Button>
          <Button onClick={() => setShowReportGenerator(true)} variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Generar Reporte
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profesionales</CardTitle>
            <Users className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+2</span> este mes
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Citas Hoy</CardTitle>
            <Calendar className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">16</span> completadas
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Horas Esta Semana</CardTitle>
            <Clock className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">298</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-600">-12</span> vs semana anterior
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Eficiencia</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">94.2%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+1.2%</span> este mes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Citas de la Semana</CardTitle>
            <CardDescription>Agendadas vs realizadas por día</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={citasSemanales}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="dia" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="citas" fill="#2E7D32" name="Agendadas" />
                <Bar dataKey="realizadas" fill="#FBC02D" name="Realizadas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Horas Trabajadas</CardTitle>
            <CardDescription>Evolución semanal</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={horasData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="semana" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="horas" stroke="#2E7D32" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions and Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Profesionales Destacados</CardTitle>
            <CardDescription>Top performers este mes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">AM</span>
                </div>
                <div>
                  <p className="font-medium">Dra. Ana María González</p>
                  <p className="text-sm text-gray-500">Cardiología</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-700">98.5%</p>
                <p className="text-xs text-gray-500">Eficiencia</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">CR</span>
                </div>
                <div>
                  <p className="font-medium">Dr. Carlos Rodríguez</p>
                  <p className="text-sm text-gray-500">Neurología</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-700">96.8%</p>
                <p className="text-xs text-gray-500">Eficiencia</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">LM</span>
                </div>
                <div>
                  <p className="font-medium">Dra. Laura Martínez</p>
                  <p className="text-sm text-gray-500">Pediatría</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-700">95.2%</p>
                <p className="text-xs text-gray-500">Eficiencia</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle>Alertas y Notificaciones</CardTitle>
            <CardDescription>Requieren tu atención</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-yellow-800">Cita sin confirmar</p>
                <p className="text-sm text-yellow-700">
                  Paciente Juan Pérez - Mañana 10:00 AM
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
              <UserCheck className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-blue-800">Nuevo profesional</p>
                <p className="text-sm text-blue-700">
                  Dr. Miguel Torres requiere aprobación
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
              <CalendarCheck className="h-5 w-5 text-green-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-green-800">Meta alcanzada</p>
                <p className="text-sm text-green-700">
                  100% de citas completadas esta semana
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <CitaForm
        open={showCitaForm}
        onOpenChange={setShowCitaForm}
        onSuccess={() => {
          console.log('Cita creada exitosamente')
        }}
      />

      <HorasForm
        open={showHorasForm}
        onOpenChange={setShowHorasForm}
        onSuccess={() => {
          console.log('Horas registradas exitosamente')
        }}
      />

      {showReportGenerator && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Generar Reporte</h2>
              <Button variant="ghost" onClick={() => setShowReportGenerator(false)}>
                ✕
              </Button>
            </div>
            <ReportGenerator />
          </div>
        </div>
      )}
    </div>
  )
}
