'use client'

import { useState } from 'react'
import { CalendarView } from '@/components/calendar/calendar-view'
import { CitaForm } from '@/components/forms/cita-form'
import { useAuth } from '@/components/providers/auth-provider'

export default function CitasEmpresa() {
  const { user } = useAuth()
  const [showCitaForm, setShowCitaForm] = useState(false)

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestión de Citas</h1>
        <p className="text-gray-600 mt-2">Administra las citas de tu centro médico</p>
      </div>

      <CalendarView 
        empresaId={user?.empresaId}
        onNewCita={() => setShowCitaForm(true)}
      />

      <CitaForm
        open={showCitaForm}
        onOpenChange={setShowCitaForm}
        onSuccess={() => {
          console.log('Cita creada exitosamente')
        }}
      />
    </div>
  )
}
