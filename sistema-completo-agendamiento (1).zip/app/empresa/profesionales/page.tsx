'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Plus, Search, Users, Mail, Phone, UserCheck } from 'lucide-react'
import { mockProfesionales } from '@/lib/data/mock-data'
import { useAuth } from '@/components/providers/auth-provider'

export default function ProfesionalesEmpresa() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState('')

  const profesionalesEmpresa = mockProfesionales.filter(p => p.empresaId === user?.empresaId)
  const profesionalesFiltrados = profesionalesEmpresa.filter(p =>
    p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.especialidad.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Profesionales</h1>
          <p className="text-gray-600 mt-2">Gestiona el equipo médico de tu empresa</p>
        </div>
        <Button className="seguros-button-primary">
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Profesional
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Profesionales</CardTitle>
            <Users className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profesionalesEmpresa.length}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">{profesionalesEmpresa.filter(p => p.activo).length}</span> activos
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Especialidades</CardTitle>
            <UserCheck className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Set(profesionalesEmpresa.map(p => p.especialidad)).size}
            </div>
            <p className="text-xs text-muted-foreground">
              Diferentes especialidades
            </p>
          </CardContent>
        </Card>

        <Card className="seguros-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Promedio Citas/Día</CardTitle>
            <UserCheck className="h-4 w-4 text-[#2E7D32]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8.5</div>
            <p className="text-xs text-muted-foreground">
              Por profesional
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="seguros-card">
        <CardHeader>
          <CardTitle>Lista de Profesionales</CardTitle>
          <CardDescription>
            Administra y supervisa tu equipo médico
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-6">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por nombre o especialidad..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {profesionalesFiltrados.map(profesional => (
              <Card key={profesional.id} className="seguros-card">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-12 h-12 bg-[#2E7D32] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold">
                        {profesional.nombre.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <Badge 
                      variant={profesional.activo ? 'default' : 'secondary'}
                      className={profesional.activo ? 'bg-green-100 text-green-800' : ''}
                    >
                      {profesional.activo ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </div>
                  
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {profesional.nombre}
                  </h3>
                  <p className="text-sm text-[#2E7D32] font-medium mb-3">
                    {profesional.especialidad}
                  </p>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2" />
                      {profesional.email}
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2" />
                      {profesional.telefono}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 mt-4">
                    <Button variant="outline" size="sm" className="flex-1">
                      Ver Perfil
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      Editar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {profesionalesFiltrados.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No se encontraron profesionales</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
