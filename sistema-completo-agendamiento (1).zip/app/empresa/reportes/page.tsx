'use client'

import { ReportGenerator } from '@/components/reports/report-generator'

export default function ReportesEmpresa() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Reportes</h1>
        <p className="text-gray-600 mt-2">Genera reportes detallados de tu empresa</p>
      </div>

      <ReportGenerator />
    </div>
  )
}
