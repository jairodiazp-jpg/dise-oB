'use client'

import { useState } from 'react'
import { SecureLogin } from '@/components/auth/secure-login'
import { ChatbotSupport } from '@/components/auth/chatbot-support'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Settings, Upload, Sparkles } from 'lucide-react'
import Image from 'next/image'

export default function LoginPage() {
  const [logoUrl, setLogoUrl] = useState('')
  const [tempLogoUrl, setTempLogoUrl] = useState('')
  const [showLogoDialog, setShowLogoDialog] = useState(false)
  const [logoError, setLogoError] = useState(false)

  const handleSaveLogo = () => {
    if (tempLogoUrl.trim()) {
      setLogoUrl(tempLogoUrl)
      setLogoError(false)
      localStorage.setItem('seguros-logo-url', tempLogoUrl)
    }
    setShowLogoDialog(false)
  }

  const handleImageError = () => {
    setLogoError(true)
  }

  // Cargar logo guardado al iniciar
  useState(() => {
    const savedLogo = localStorage.getItem('seguros-logo-url')
    if (savedLogo) {
      setLogoUrl(savedLogo)
    }
  })

  return (
    <div className="min-h-screen seguros-gradient flex items-center justify-center p-4 relative overflow-hidden">
      {/* Elementos decorativos de fondo */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-yellow-400/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
      </div>

      {/* Botón de configuración de logo */}
      <Dialog open={showLogoDialog} onOpenChange={setShowLogoDialog}>
        <DialogTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="absolute top-4 right-4 text-white hover:bg-white/20 backdrop-blur-sm border border-white/20 font-medium"
          >
            <Settings className="h-4 w-4 mr-2" />
            Configurar Logo
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[400px] seguros-card">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Upload className="h-5 w-5 mr-2 text-green-700" />
              🎨 Configurar Logo de la Empresa
            </DialogTitle>
            <DialogDescription>
              Personaliza el logo que aparece en la pantalla de inicio de sesión.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="logoUrl">URL de la imagen</Label>
              <Input
                id="logoUrl"
                type="url"
                value={tempLogoUrl}
                onChange={(e) => setTempLogoUrl(e.target.value)}
                placeholder="https://ejemplo.com/logo.png"
                className="seguros-input"
              />
              <p className="text-xs text-gray-600">
                💡 Recomendado: Imagen cuadrada, mínimo 200x200px, formato PNG o JPG
              </p>
            </div>
            
            {tempLogoUrl && (
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Vista previa:</p>
                <div className="w-24 h-24 mx-auto bg-gradient-to-r from-gray-100 to-gray-200 rounded-full flex items-center justify-center overflow-hidden border-4 border-green-100 shadow-lg">
                  <Image
                    src={tempLogoUrl || "/placeholder.svg"}
                    alt="Vista previa del logo"
                    width={96}
                    height={96}
                    className="object-contain rounded-full"
                    onError={() => setLogoError(true)}
                  />
                </div>
                {logoError && (
                  <p className="text-xs text-red-600 mt-2">
                    ❌ Error al cargar la imagen. Verifica la URL.
                  </p>
                )}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowLogoDialog(false)}>
              Cancelar
            </Button>
            <Button type="button" onClick={handleSaveLogo} className="seguros-button-primary">
              <Sparkles className="h-4 w-4 mr-2" />
              Guardar Logo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Contenido principal */}
      <Card className="w-full max-w-md seguros-card backdrop-blur-sm bg-white/98 relative z-10 shadow-2xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="seguros-logo-container">
              {logoUrl && !logoError ? (
                <Image
                  src={logoUrl || "/placeholder.svg"}
                  alt="Logo de la empresa"
                  width={96}
                  height={96}
                  className="object-contain rounded-full"
                  onError={handleImageError}
                />
              ) : (
                <div className="text-3xl font-bold bg-gradient-to-r from-green-700 to-green-600 bg-clip-text text-transparent">
                  SB
                </div>
              )}
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-green-600 bg-clip-text text-transparent mb-2">
              Seguros Bolívar
            </h1>
            <p className="text-gray-600 text-lg font-medium">Sistema de Agendamiento Médico</p>
            <div className="w-20 h-1 bg-gradient-to-r from-green-600 to-yellow-400 mx-auto mt-4 rounded-full shadow-sm"></div>
          </div>
          <SecureLogin />
        </CardContent>
      </Card>

      {/* Chatbot de soporte */}
      <ChatbotSupport />
    </div>
  )
}
